<?php $__env->startSection('content'); ?>


<section class="body-banner dashboard_profile-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-3">
            <h2>Account Information</h2>
        </div>
        <div class="user_acc_info-wrapper">
            

            <div class="row">
                <div class="col-md-6">
                    <b>Card for Subscription</b>
                    
                    <?php
                        $card = $user->userCards()->orderBy('id', 'desc')->first();
                    ?>

                    <?php if(@$card): ?>
                    <p>Card Name: <?php echo e($card->card_name); ?></p>
                    <p>Card Number: **** <?php echo e($card->card_number); ?></p>
                    <p>Card Type: <?php echo e($card->card_type); ?></p>

                    <form class="form-design row justify-content-center" method="post" action="<?php echo e(route('lawyer.card.remove')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-design-first btn_bank">Remove Card</button>
                    </form>
                    <?php else: ?>
                    <form class="form-design row justify-content-center" method="post" action="<?php echo e(route('lawyer.card.store')); ?>">
                        <?php echo csrf_field(); ?>


                        <div class="billing-info_form-inputs">

                            <div class="form-grouph input-design<?php echo ($errors->has('card_name') ? ' has-error' : ''); ?>">
                                <?php echo Form::label('card_name', 'Name on Card', ['class' => 'form-label']); ?>

                                <?php echo Form::text('card_name', null, ['class' => ($errors->has('card_name') ? ' is-invalid' : '')]); ?>

                                <?php echo $errors->first('card_name', '<span class="help-block">:message</span>'); ?>

                            </div>

                            <div class="form-grouph input-design<?php echo ($errors->has('card_number') ? ' has-error' : ''); ?>">
                                <?php echo Form::label('card_number', 'Card Number', ['class' => 'form-label']); ?>

                                <?php echo Form::number('card_number', null, ['class' => ($errors->has('card_number') ? ' is-invalid' : '')]); ?>

                                <?php echo $errors->first('card_number', '<span class="help-block">:message</span>'); ?>

                            </div>



                            <div class="form-flex three-columns">
                                <div class="form-grouph input-design">
                                    <label>Expiration Month</label>
                                    <select name="expire_month" class="form-control" placeholder="Exp Month">
                                        <option value="">Select Month</option>
                                        <?php for($i = 1; $i <=12; $i++): ?>
                                        <option value="<?php echo e($i<=9 ? '0'.$i : $i); ?>"><?php echo e(date('F', mktime(0,0,0,$i))); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <?php echo $errors->first('expire_month', '<span class="help-block">:message</span>'); ?>

                                </div>
                                <div class="form-grouph input-design">
                                    <label>Expiration Year</label>
                                    <select name="expire_year" class="form-control" placeholder="Expiration Year">
                                        <option value="">Select Year</option>
                                        <?php for($i = 0; $i <10; $i++): ?>
                                        <?php $year = date('Y') + $i; ?>
                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <?php echo $errors->first('expire_year', '<span class="help-block">:message</span>'); ?>

                                </div>
                                <div class="form-grouph input-design">
                                    <label>CVV</label>
                                    <input type="number" placeholder="CVV" name="cvv">
                                    <?php echo $errors->first('cvv', '<span class="help-block">:message</span>'); ?>

                                </div>
                            </div>



                            </div>



                        <button type="submit" class="btn-design-first btn_bank">Add Card</button>
                    </form>
                    <?php endif; ?>

                </div>

                <div class="col-md-6">


                    <?php if(@$record): ?>
                        <?php if(@$bankInfo->status=='active'): ?>
                            <?php if(!$record->account_number): ?>
                                <p class="text-center pb-3">Please fill the bank account to complete your bank account verification.</p>
                            <?php endif; ?>
                            <form class="form-design row justify-content-center" method="post" action="<?php echo e(route('lawyer.banking.store')); ?>">
                                <?php echo csrf_field(); ?>
                
                                <div class="col-md-7">
                                <div class="white-shadow-scnd-box ">
                                    <div class="form">
                                        <div class="form-grouph input-design">
                                            <label>Account Holder Name*</label>
                                            <input class="<?php $__errorArgs = ['account_holder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="account_holder_name" value="<?php echo e(@$record->account_holder_name); ?>">
                                            <?php $__errorArgs = ['account_holder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="help-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-grouph input-design">
                                            <label>Account Number*</label>
                                            <input class="<?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="account_number" value="<?php echo e(@$record->account_number); ?>">
                                            <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="help-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-grouph input-design">
                                            <label>Routing Number*</label>
                                            <input class="<?php $__errorArgs = ['routing_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="routing_number" value="<?php echo e(@$record->routing_number); ?>">
                                            <?php $__errorArgs = ['routing_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="help-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                
                                    </div>
                                </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
                                        <div class="form-grouph submit-design text-center">
                                            
                                            <input type="submit" value="<?php echo e(@$record->account_number ? 'Edit' : 'Add'); ?> Account" class="btn-design-second">
                                            
                                        </div>
                                    </div>
                                </div>
                            </form>
                        <?php else: ?>
                            <?php echo Form::open(['route' => 'lawyer.bank.connect', 'class'=>'form-design row justify-content-center']); ?>

                			<button type="submit" class="btn-design-first btn_bank">Connect Bank Account</button>
                			<?php echo Form::close(); ?>

                        <?php endif; ?>
                    <?php else: ?>
                        <?php echo Form::open(['route' => 'lawyer.bank.connect', 'class'=>'form-design row justify-content-center']); ?>

            			<button type="submit" class="btn-design-first btn_bank">Connect Bank Account</button>
            			<?php echo Form::close(); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/lawyer/profile/account.blade.php ENDPATH**/ ?>