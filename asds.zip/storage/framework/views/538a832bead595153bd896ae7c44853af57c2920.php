<?php $__env->startSection('content'); ?>
<section class="body-banner authentication-sec min-height-100vh login-sec">
	<div class="container">
		<div class="authentication-container">
			<div class="authentication-header">
				<h2>User Login</h2>
			</div>
			<div class="lawyer-login">
				<?php echo Form::open(['route' => 'login', 'class'=>'form-design']); ?>

				<div class="white-shadow-box">

					<div class="form-grouph input-design<?php echo ($errors->has('email') ? ' has-error' : ''); ?>">
						<?php echo Form::label('email','Email', ['class' => 'form-label']); ?>

						<?php echo Form::email('email', request()->email ?? null, ['class' => ($errors->has('email') ? ' is-invalid' : '')]); ?>

						<?php echo $errors->first('email', '<span class="help-block">:message</span>'); ?>

					</div>

					<div class="form-grouph input-design<?php echo ($errors->has('email') ? ' has-error' : ''); ?>">
						<?php echo Form::label('password','Password', ['class' => 'form-label']); ?>

						<input type="password" id="password" name="password" class="<?php echo ($errors->has('email') ? ' is-invalid' : ''); ?>" />
						<?php echo $errors->first('password', '<span class="help-block">:message</span>'); ?>

					</div>


					<?php if(Route::has('password.request')): ?>
					<div class="forgot-password text-center">
						<a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Password?')); ?></a>
					</div>
					<?php endif; ?>

					<div class="form-grouph submit-design text-center">
						<button class="form-btn" type="submit"><?php echo e(__ ('Login')); ?></button>
					</div>

					<?php if(Route::has('register')): ?>
					<div class="account-availblity-div text-center">
						<p>Don’t have an account? <a href="<?php echo e(route('register')); ?>">Sign Up.</a></p>
					</div>
					<?php endif; ?>
				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/auth/login.blade.php ENDPATH**/ ?>