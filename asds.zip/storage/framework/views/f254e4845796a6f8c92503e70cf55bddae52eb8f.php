<?php
$details = $user->details;
$lawyer_details = $user->lawyerInfo;
$lawyer_state_bar = $user->lawyerStateBar;

?>


<div class="lawyer_profile-wrapper">
    <?php echo Form::open(['route' => 'lawyer.profile.update', 'class'=>'lawyer_profile-information form-design']); ?>

    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
            <div class="white-shadow-scnd-box">
                <div class="form-heading">
                    <h4 class="h4-design">Information about you</h4>
                </div>

                <div class="lawyer_profile-img mb-3">
                    <div class="circle" id="uploaded">
                        <img class="profile-pic" src="<?php echo e($user->profile_pic); ?>">
                    </div>
                    <div class="p-image">
                        <span class="pencil_icon"><i class="fa-solid fa-pencil upload-button"></i></span>
                        <input class="file-upload" id="upload" type="file" accept="image/*" />
                        <input type="hidden" name="image" id="upload-img" />
                    </div>
                </div>


                <div class="form-grouph textarea-design<?php echo ($errors->has('bio') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('bio','Bio*', ['class' => 'form-label']); ?>

                    <?php echo Form::textarea('bio', $details->bio ?? null, ['class' => ($errors->has('bio') ? ' is-invalid' : ''), 'placeholder'=>'Tell us about yourself']); ?>

                    <?php echo $errors->first('bio', '<span class="help-block">:message</span>'); ?>

                </div>

                


                <div class="form-grouph checkbox-label-block">
                    <div class="d-flex align-items-center justify-content-spacebw">
                        <?php echo Form::label('contingency_cases','Do you accept contingency cases?*', ['class' => 'form-label']); ?>

                        <div class="d-flex align-items-center">
                            <div class="checkbox-design position-relative">
                                <input type="radio" name="contingency_cases" value="yes" <?php echo e(@$details->contingency_cases=='yes'?'checked':''); ?>>
                                <button class="checkbox-btn"></button>
                                <label>Yes</label>
                            </div>
                            <div class="checkbox-design position-relative">
                                <input type="radio" name="contingency_cases" value="no" <?php echo e(@$details->contingency_cases=='no'?'checked':''); ?>>
                                <button class="checkbox-btn"></button>
                                <label>No</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-grouph checkbox-label-block">
                    <div class="d-flex align-items-center justify-content-spacebw">
                        <?php echo Form::label('is_consultation_fee','Do you want to charge a consultation fee?*', ['class' => 'form-label']); ?>

                        <div class="d-flex align-items-center">
                            <div class="checkbox-design position-relative">
                                <input type="radio" name="is_consultation_fee" value="yes" <?php echo e(@$details->is_consultation_fee=='yes'?'checked':''); ?>>
                                <button class="checkbox-btn"></button>
                                <label>Yes</label>
                            </div>
                            <div class="checkbox-design position-relative">
                                <input type="radio" name="is_consultation_fee" value="no" <?php echo e(@$details->is_consultation_fee=='no'?'checked':''); ?>>
                                <button class="checkbox-btn"></button>
                                <label>No</label>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="form-flex hour_rate_form">
                    
                    <div class="form-grouph input-grouph input-design<?php echo ($errors->has('hourly_fee') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('hourly_fee','Hourly Rate*', ['class' => 'form-label']); ?>

                    <div class="input-group-prepend">
                            <span class="">$</span>
                        </div> 
                        <?php echo Form::number('hourly_fee', $details->hourly_fee ?? null, ['class' => ($errors->has('hourly_fee') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('hourly_fee', '<span class="help-block">:message</span>'); ?>

                    </div>

                    <div class=" form-grouph  input-grouph input-design<?php echo ($errors->has('consultation_fee') ? ' has-error' : ''); ?>">
                       <div class="question_div">
                         <?php echo Form::label('consultation_fee','Consultation Fee*', ['class' => 'form-label']); ?><span>?</span>
                       </div>
                        <div class="input-group-prepend">
                            <span class="">$</span>
                        </div> 
                        <?php echo Form::number('consultation_fee', $details->consultation_fee ?? null, ['class' => ($errors->has('consultation_fee') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('consultation_fee', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>

                <div class="form-grouph input-design<?php echo ($errors->has('website_url') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('website_url','Website URL', ['class' => 'form-label']); ?>

                    <?php echo Form::url('website_url', $details->website_url ?? null, ['class' => ($errors->has('website_url') ? ' is-invalid' : '')]); ?>

                    <?php echo $errors->first('website_url', '<span class="help-block">:message</span>'); ?>

                </div>

                <div class="form-flex">
                    <div class="form-grouph input-design<?php echo ($errors->has('first_name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('first_name','First Name*', ['class' => 'form-label']); ?>

                        <?php echo Form::text('first_name', $user->first_name ?? null, ['class' => ($errors->has('first_name') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('first_name', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph input-design<?php echo ($errors->has('last_name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('last_name','Last Name*', ['class' => 'form-label']); ?>

                        <?php echo Form::text('last_name', $user->last_name ?? null, ['class' => ($errors->has('last_name') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('last_name', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>

                <div class="form-flex">
                    <div class="form-grouph input-design<?php echo ($errors->has('contact_number') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('contact_number','Phone', ['class' => 'form-label']); ?>

                        <?php echo Form::text('contact_number', $user->contact_number ?? null, ['class' => 'phone '.($errors->has('contact_number') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('contact_number', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph input-design<?php echo ($errors->has('email') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('email','Email', ['class' => 'form-label']); ?>

                        <?php echo Form::email('email', $user->email ?? null, ['class' => ($errors->has('email') ? ' is-invalid' : ''), 'disabled']); ?>

                        <?php echo $errors->first('email', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>

                <div class="form-grouph input-design<?php echo ($errors->has('address') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('address','Address*', ['class' => 'form-label']); ?>

                    <?php echo Form::text('address', $details->address ?? null, ['class' => ($errors->has('address') ? ' is-invalid' : '')]); ?>

                    <?php echo $errors->first('address', '<span class="help-block">:message</span>'); ?>

                </div>

                <div class="form-flex three-columns">
                    <div class="form-grouph input-design<?php echo ($errors->has('city') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('city','City*', ['class' => 'form-label']); ?>

                        <?php echo Form::text('city', $details->city ?? null, ['class' => ($errors->has('city') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('city', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph select-design<?php echo ($errors->has('state') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('state','State*', ['class' => 'form-label']); ?>

                        <?php echo Form::select('state', $states, $details->state ?? null, ['class' => ($errors->has('state') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('state', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph input-design<?php echo ($errors->has('zip_code') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('zip_code','Zip Code*', ['class' => 'form-label']); ?>

                        <?php echo Form::text('zip_code', $details->zip_code ?? null, ['class' => ($errors->has('zip_code') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('zip_code', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('lawyer.practice-areas')->html();
} elseif ($_instance->childHasBeenRendered('ywGf6R5')) {
    $componentId = $_instance->getRenderedChildComponentId('ywGf6R5');
    $componentTag = $_instance->getRenderedChildComponentTagName('ywGf6R5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ywGf6R5');
} else {
    $response = \Livewire\Livewire::mount('lawyer.practice-areas');
    $html = $response->html();
    $_instance->logRenderedChild('ywGf6R5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>





                <!-- <div class="form-grouph select-design">
                    <?php $__currentLoopData = $categoriesMulti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-grouph input-design">
                        <?php if($category->is_category=='1'): ?>
                        <h5 class="h5_titile_form pt-3">Federal court admissions</h5>
                       ( <?php echo e($category->name); ?>)*
                        <?php else: ?>
                        <label> <?php echo e($category->name); ?>*</label>
                        <?php endif; ?>

                    </div>
                    <select class="select-block multiBoxes" multiple>
                        <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($list->id); ?>" data-cat="<?php echo e($category->id); ?>" data-name="<?php echo e($list->name); ?>" <?php $__currentLoopData = $lawyer_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($list->id==$item->item_id): ?>
                            data-year="<?php echo e($item->year_admitted); ?>"
                            data-bar="<?php echo e($item->bar_number); ?>"
                            selected
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            >
                            <?php echo e($list->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $errors->first('lawyer_info.'.$category->id, '<span class="help-block">:message</span>'); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="form-grouph input-design<?php echo ($errors->has('year_experience') ? ' has-error' : ''); ?>">
                    <label>Years of Experience <span class="label_color">?</span></label>
                    <?php echo Form::text('year_experience', $details->year_experience ?? null, ['class' => ($errors->has('year_experience') ? ' is-invalid' : ''), 'maxlength'=>'2']); ?>

                    <?php echo $errors->first('year_experience', '<span class="help-block">:message</span>'); ?>

                </div> -->
                
                <div class="admissionHtml"></div>

                

            </div>
        </div>
        
        <?php echo $__env->make('lawyer.profile.hours', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
            <div class="form-grouph submit-design text-center">
                <button type="submit" class="btn-design-first">Update Profile</button>
            </div>
        </div>
    </div>
    <?php echo Form::close(); ?>


</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/lawyer/profile/form.blade.php ENDPATH**/ ?>