import './bootstrap';
import '../css/app.css'

       
import Zoom from './components/Zoom';


