[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>