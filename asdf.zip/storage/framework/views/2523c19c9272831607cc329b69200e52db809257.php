<?php $__env->startSection('content'); ?>
<section class="body-banner portal-inner-page-sec">
      <div class="container">
         <div class="heading-paragraph-design text-center position-relative mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
         </div>
        <div class="portal-page-wrapper">
           <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
              <div class="portal-div-design position-relative">
                <div class="portal-div-img">
                  <img src="assets/images/schedule.svg">
                </div>
                <div class="portal-cntnt-wrapper">
                   <a href="<?php echo e(route('consultations.upcoming')); ?>">Consultations</a>
                </div>
             </div>

            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
              <div class="portal-div-design position-relative">
                <div class="portal-div-img">
                  <img src="assets/images/saved-lawyers.svg">
                </div>
                <div class="portal-cntnt-wrapper">
                   <a href="<?php echo e(route('user.saved.lawyer')); ?>">Saved Lawyers</a>
                </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
              <div class="portal-div-design position-relative">
                <div class="portal-div-img">
                  <img src="assets/images/account-portal.svg">
                </div>
                <div class="portal-cntnt-wrapper">
                   <a href="<?php echo e(route('user.profile')); ?>">Account</a>
                </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
              <div class="portal-div-design position-relative">
                <div class="portal-div-img">

                  <img src="assets/images/account-portal.svg">
                </div>
                <div class="portal-cntnt-wrapper">
                   <a href="<?php echo e(route('user.billing.index')); ?>">Billing</a>
                </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
              <div class="portal-div-design position-relative">
                <div class="portal-div-img">
                  <img src="assets/images/services-portal.svg">
                </div>
                <div class="portal-cntnt-wrapper">
                   <a href="<?php echo e(route('support')); ?>">Support</a>
                </div>
              </div>
            </div>
           </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/user/dashboard/index.blade.php ENDPATH**/ ?>