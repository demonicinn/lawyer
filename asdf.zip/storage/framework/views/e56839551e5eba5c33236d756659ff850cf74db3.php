<?php $__env->startSection('content'); ?>
<section class="body-banner per-info-page-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('lawyer.subscriptions')->html();
} elseif ($_instance->childHasBeenRendered('7hxtv4N')) {
    $componentId = $_instance->getRenderedChildComponentId('7hxtv4N');
    $componentTag = $_instance->getRenderedChildComponentTagName('7hxtv4N');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7hxtv4N');
} else {
    $response = \Livewire\Livewire::mount('lawyer.subscriptions');
    $html = $response->html();
    $_instance->logRenderedChild('7hxtv4N', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/lawyer/subscription/index.blade.php ENDPATH**/ ?>