<div>
    <div class="lawyer-service-list-sec d-flex flex-wrap">
        <div id="filter-sidebar" class="sidebar-wrap">
            <form class="form-design">
                <div class="filter-sidebar">
                    <h4>Filter by:</h4>
                    <div class="hourly-range-design range-design mb-5">
                        <h5 class="h5-design">Hourly Rate</h5>
                        <div class="n-slider" wire:ignore>
                            <!-- <p class="min-value">$0</p> -->
                            <input type="text" id="hourlyRange" readonly>
                            <div id="hourly-range" class="slider"></div>
                            <!-- <p class="max-value">$500</p> -->
                        </div>
                        
                        
                    </div>

                    <div class="toggle-design-wrapper d-flex flex-wrap align-items-center mb-4 justify-content-spacebw">
                        <h5 class="h5-design">Free Consultation</h5>
                        <div class="toggle-design_div">
                            <input type="checkbox" wire:model="free_consultation"  name="free-consultation">
                            <button class="cstm-toggle-btn"></button>
                        </div>
                    </div>

                    <div class="toggle-design-wrapper d-flex flex-wrap align-items-center mb-4 justify-content-spacebw">
                        <h5 class="h5-design">Contingency Cases</h5>
                        <div class="toggle-design_div">
                            <input id="contingency-cases" type="checkbox" wire:model="contingency_cases" name="contingency-cases">
                            <button class="cstm-toggle-btn"></button>
                        </div>
                    </div>

                    <div class="year-exp-design range-design mb-5">
                        <h5 class="h5-design">Years Experience</h5>
                        
                        <div class="n-slider" wire:ignore>
                            <!-- <p class="min-value">1</p> -->
                            <input type="text" id="yearsRange" readonly>
                            <div id="years-range" class="slider"></div>
                            <!-- <p class="max-value">20</p> -->
                        </div>
                        
                        
                    </div>

                    <div class="form-group select-design form-grouph mb-4">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->items_count): ?>
                        <div class="form-grouph input-design">
                            <label> <?php echo e($category->name); ?>*</label>
                        </div>
                        <select wire:model="category.<?php echo e($category->id); ?>">
                            <option value="">Select <?php echo e($category->name); ?></option>
                            <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>">
                                <?php echo e($list->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="distance-within-design range-design form-grouph mb-5">
                        <h5 class="h5-design">Within Distance</h5>
                        <div class="n-slider" wire:ignore>
                            <!-- <p class="min-value">1 mi</p> -->
                            <input type="text" id="distanceRange" readonly>
                            <div id="distance-range" class="slider"></div>
                            <!-- <p class="max-value">100 mi</p> -->
                        </div>
                        
                        
                    </div>

                    <div class="form-group input-design form-grouph icon-input-design dark-placehiolder">
                        <input type="search" wire:model.debounce.500ms="search" placeholder="Search">
                        <span class="input_icn"><i class="fa-solid fa-magnifying-glass"></i></span>
                    </div>
                </div>
            </form>
        </div>


        <div class="lawyers-list-sec">
            <div class="list-wrapper list-service">

                <?php $__empty_1 = true; $__currentLoopData = $lawyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="list-item list-service-item">
                    <div class="lawyer-hire-block">
                        <?php if(@$lawyer->profile_pic): ?>
                        <div class="lawyers-img-block border-10">
                            <img src="<?php echo e($lawyer->profile_pic); ?>">
                        </div>
                        <?php endif; ?>
                        <div class="lawyers-service-cntnt-block">
                            <div class="lawyers-heading_service d-flex justify-content-spacebw align-items-center">
                                <h4 class="lawyer-name"><?php echo e(@$lawyer->name); ?></h4>
                                <button class="hire-price-btn">$<?php echo e(@$lawyer->details->hourly_fee); ?>/hr.</button>
                            </div>
                            <div class="lawyers-desc_service d-flex justify-content-spacebw">
                                <div class="years_experience_div">
                                    <p>YEARS EXP.</p>
                                    <h4><?php echo e(@$lawyer->details->year_experience); ?></h4>
                                </div>
                                <div class="contingency-cases_div">
                                    <p>CONTINGENCY CASES</p>
                                    <h4><?php echo e(@ucfirst($lawyer->details->contingency_cases)); ?></h4>
                                </div>
                                <div class="consult-fee_div">
                                    <p>CONSULT FEE</p>


                                    <h4><?php echo e(@$lawyer->details->is_consultation_fee=='yes' ? '$'.$lawyer->details->consultation_fee : 'Free'); ?></h4>
                                </div>
                            </div>
                            <p class="school_name"><i class="fa-solid fa-school-flag"></i><?php echo e(@$lawyer->lawyerCategory->items->name); ?></p>
                            <div class="location_profile-divs border-bottom pb-2">
                                <address><i class="fa-solid fa-location-dot"></i> <?php echo e(@$lawyer->details->city); ?>, <?php echo e(@$lawyer->details->states->code); ?></address>
                                
                            </div>

                            <div class="add-litigations mt-2 location_profile-divs d-flex justify-content-spacebw align-items-center ">
                                <button type="button" class="btn_court showModal " wire:click="modalData(<?php echo e($lawyer->id); ?>)"><i class="fa-solid fa-gavel"></i>  Admission</button>
                                <a href="<?php echo e(route('lawyer.show', $lawyer->id)); ?>?type=<?php echo e($search_type); ?>&search=<?php echo e(json_encode($search_data)); ?>">See Profile</a>
                            </div>

                            <?php $lawyerID = Crypt::encrypt($lawyer->id); ?>
                            
                            <?php if(auth()->check()): ?>
                            <?php if(auth()->user()->role=='user'): ?>
                            <div class="schedular_consultation">
                                <a href="<?php echo e(route('schedule.consultation', $lawyerID)); ?>?type=<?php echo e($search_type); ?>&search=<?php echo e(json_encode($search_data)); ?>" class="schule_consultation-btn">Schedule Consultation</a>
                            </div>
                            <?php endif; ?>
                            <?php else: ?>
                            <div class="schedular_consultation">
                                <a href="<?php echo e(route('schedule.consultation', $lawyerID)); ?>?type=<?php echo e($search_type); ?>&search=<?php echo e(json_encode($search_data)); ?>" class="schule_consultation-btn">Schedule Consultation</a>
                            </div>
                            <?php endif; ?>


                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4>No lawyers found</h4>
                <?php endif; ?>



                <?php if($modal): ?>
                <!-- Accept Modal Start Here-->
                <div wire:ignore.self class="modal fade courts_modal common_modal modal-design" id="courtModal" tabindex="-1" aria-labelledby="courtModal" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                        <button type="button" class="btn btn-default close closeModal">
                            <i class="fas fa-close"></i>
                        </button>
                            <div class="modal-header modal_h">

                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                  <?php if($modal->lawyerInfo): ?>
                                  <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Federal Court Admissions</button>
                                  </li>
                                  <?php endif; ?>

                                  <?php if($modal->lawyerStateBar): ?>
                                  <li class="nav-item" role="presentation">
                                    <button class="nav-link <?php echo e(!$modal->lawyerInfo ? 'active' : ''); ?>" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">State Bar Admissions</button>
                                  </li>
                                  <?php endif; ?>
                                </ul>

                            </div>
                            <div class="modal-body">

                                <div class="tab-content" id="myTabContent">
                                    <?php if($modal->lawyerInfo): ?>
                                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <?php $__currentLoopData = $modal->lawyerInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyerInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-4 courts_data">
                                           <div class="name_data_p">
                                             <h6><?php echo e(@$lawyerInfo->items->name); ?></h6>
                                            <p class="mb-0"><?php echo e(@$lawyerInfo->items->category->name); ?> <?php echo e(@$lawyerInfo->items->category->mainCat->name ? ' - '.$lawyerInfo->items->category->mainCat->name : ''); ?></p>
                                           </div>
                                            <div class="federal-court">
                                                <div class="form-grouph select-design">
                                                    <label>Bar Number</label>
                                                    <div><?php echo e(@$lawyerInfo->bar_number ?? '--'); ?></div>
                                                </div>
                                                <div class="form-grouph select-design">
                                                    <label>Year Admitted</label>
                                                    <div><?php echo e($lawyerInfo->year_admitted ?? '--'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($modal->lawyerStateBar): ?>
                                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                        <?php $__currentLoopData = $modal->lawyerStateBar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-4 courts_data">
                                           <div class="name_data_p">
                                             <h6><?php echo e(@$item->statebar->name); ?></h6>
                                           </div>
                                            <div class="federal-court">
                                                <div class="form-grouph select-design">
                                                    <label>Bar Number</label>
                                                    <div><?php echo e(@$item->bar_number ?? '--'); ?></div>
                                                </div>
                                                <div class="form-grouph select-design">
                                                    <label>Year Admitted</label>
                                                    <div><?php echo e($item->year_admitted ?? '--'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- Accept Modal Close Here-->
                <?php endif; ?>


                <div id="pagination-container" class="pagination-container-service">
                    <?php echo $lawyers->links(); ?>

                </div>
            </div>
        </div>

        <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {

                window.livewire.on('courtModalShow', () => {
                    $('#courtModal').modal('show');
                });
            });
            $(document).on('click', '.showModal', function(e) {
                $('#courtModal').modal('show');
            });
            $(document).on('click', '.closeModal', function(e) {
                $('#courtModal').modal('hide');
            });
            
            
            //...
  
            $(function() {
                $("#hourly-range").slider({
                    step: 5,
                    range: true, 
                    min: 0, 
                    max: 500, 
                    values: [0, 500], 
                    slide: function(event, ui)
                    {
                        $("#hourlyRange").val(ui.values[0] + " - " + ui.values[1]);
                        
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('rate_min', ui.values[0]);
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('rate', ui.values[1]);
                    }
                });
                
                $("#hourlyRange").val($("#hourly-range").slider("values", 0) + " - " + $("#hourly-range").slider("values", 1));
            
            });
            
            
            $(function() {
                $("#years-range").slider({
                    step: 1,
                    range: true, 
                    min: 1, 
                    max: 20, 
                    values: [1, 20], 
                    slide: function(event, ui)
                    {
                        $("#yearsRange").val(ui.values[0] + " - " + ui.values[1]);
                        
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('year_exp_min', ui.values[0]);
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('year_exp', ui.values[1]);
                    }
                });
                
                $("#yearsRange").val($("#years-range").slider("values", 0) + " - " + $("#years-range").slider("values", 1));
            
            });
            
            
            $(function() {
                $("#distance-range").slider({
                    step: 1,
                    range: true, 
                    min: 0, 
                    max: 100, 
                    values: [0, 100], 
                    slide: function(event, ui)
                    {
                        $("#distanceRange").val(ui.values[0] + " - " + ui.values[1]);
                        
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('distance_min', ui.values[0]);
                        window.livewire.find('<?php echo e($_instance->id); ?>').set('distance', ui.values[1]);
                    }
                });
                
                $("#yearsRange").val($("#distance-range").slider("values", 0) + " - " + $("#distance-range").slider("values", 1));
            
            });
            
            

        </script>
        <?php $__env->stopPush(); ?>
    </div><?php /**PATH /home/gurpreet/Downloads/lawyer-1356ed9f629aeb5cffe79dffed5fec57d2840776/resources/views/livewire/search-lawyers.blade.php ENDPATH**/ ?>