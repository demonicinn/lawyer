<?php $__env->startSection('content'); ?>
	
	<input type="hidden" id="meeting_number" value="<?php echo e(@$booking->zoom_id); ?>">
	<input type="hidden" id="meeting_pwd" value="<?php echo e(@$booking->zoom_password); ?>">
	<input type="hidden" id="display_name" value="<?php echo e($user->name); ?>">
	<input type="hidden" id="meeting_email" value="<?php echo e($user->email); ?>">
	<input type="hidden" id="meeting_role" value="<?php echo e($user->role=='lawyer' ? 1 : 0); ?>">
	<input type="hidden" id="meeting_lang" value="en-US">
	<input type="hidden" id="meeting_china" value="0">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<link type="text/css" rel="stylesheet" href="https://source.zoom.us/2.7.0/css/bootstrap.css" />
<link type="text/css" rel="stylesheet" href="https://source.zoom.us/2.7.0/css/react-select.css" />

<script src="https://source.zoom.us/2.7.0/lib/vendor/react.min.js"></script>
<script src="https://source.zoom.us/2.7.0/lib/vendor/react-dom.min.js"></script>
<script src="https://source.zoom.us/2.7.0/lib/vendor/redux.min.js"></script>
<script src="https://source.zoom.us/2.7.0/lib/vendor/redux-thunk.min.js"></script>
<script src="https://source.zoom.us/2.7.0/lib/vendor/lodash.min.js"></script>
<script src="https://source.zoom.us/zoom-meeting-2.7.0.min.js"></script>
<script src="<?php echo e(asset('meeting/tool.js')); ?>"></script>
<script src="<?php echo e(asset('meeting/vconsole.min.js')); ?>"></script>

<script>
    window.addEventListener('DOMContentLoaded', function(event) {
	  //console.log('DOM fully loaded and parsed');
	  websdkready();
	});

	var SDK_KEY = "aQGxehQBJFFVeVORcrZ7GApWitGIPP8GHSpu";
	var SDK_SECRET = "g3ZO0EmtO0rpFzEPMFGGTehNY0XL5IykgFmS";

	function websdkready() {

		var testTool = window.testTool;
		if (testTool.isMobileDevice()) {
			vConsole = new VConsole();
		}

		var meetingConfig = testTool.getMeetingConfig();

		meetingConfig.leaveUrl = "<?php echo e(route('zoom.leave', $booking->zoom_id)); ?>";

		ZoomMtg.preLoadWasm();
	  
		var signature = ZoomMtg.generateSDKSignature({
			meetingNumber: meetingConfig.mn,
			sdkKey: SDK_KEY,
			sdkSecret: SDK_SECRET,
			role: meetingConfig.role,
			success: function (res) {
				//console.log(res.result);
				
				meetingConfig.signature = res.result;
				meetingConfig.sdkKey = SDK_KEY;

				var joinUrl = "<?php echo e(route('zoom.meet')); ?>?" + testTool.serialize(meetingConfig);
				//console.log(joinUrl);
				window.open(joinUrl);
			},
		});


	}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/common/zoom_cdn.blade.php ENDPATH**/ ?>