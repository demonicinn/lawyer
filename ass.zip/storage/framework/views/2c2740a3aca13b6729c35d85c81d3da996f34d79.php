<div>
    <div class="lawyer-service-list-sec d-flex flex-wrap">
        <div id="filter-sidebar" class="sidebar-wrap">
            <form class="form-design">
                <div class="filter-sidebar">
                    <h4>Filter by:</h4>
                    <div class="hourly-range-design range-design mb-5">
                        <h5 class="h5-design">Hourly Rate</h5>
                        <div class="range-wrapper position-relative">
                            <p class="min-value">$0</p>
                            <div id="hourly-rate-slider" class="range-slider">
                                <div id="hourly-range" class="tooltip-range"></div>
                                <input class="range_design-input" type="range" step="10" wire:model="rate" min="0" max="500">
                            </div>
                            <p class="max-value">$500</p>
                        </div>
                    </div>

                    <div class="toggle-design-wrapper d-flex flex-wrap align-items-center mb-4 justify-content-spacebw">
                        <h5 class="h5-design">Free Consultation</h5>
                        <div class="toggle-design_div">
                            <input type="checkbox" wire:model="free_consultation" name="free-consultation">
                            <button class="cstm-toggle-btn"></button>
                        </div>
                    </div>

                    <div class="toggle-design-wrapper d-flex flex-wrap align-items-center mb-4 justify-content-spacebw">
                        <h5 class="h5-design">Contingency Cases</h5>
                        <div class="toggle-design_div">
                            <input id="contingency-cases" type="checkbox" wire:model="contingency_cases" name="contingency-cases">
                            <button class="cstm-toggle-btn"></button>
                        </div>
                    </div>

                    <div class="year-exp-design range-design mb-5">
                        <h5 class="h5-design">Years Experience</h5>
                        <div class="range-wrapper position-relative">
                            <p class="min-value">1</p>
                            <div id="years-experience-slider" class="range-slider">
                                <div id="experience-range-tooltip" class="tooltip-range"></div>
                                <input wire:model="year_exp" class="range_design-input" type="range" step="1" min="0" max="20">
                            </div>
                            <p class="max-value">20</p>
                        </div>
                    </div>

                    <div class="form-group select-design form-grouph mb-4">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->items_count): ?>
                        <div class="form-grouph input-design">
                            <label> <?php echo e($category->name); ?>*</label>
                        </div>
                        <select wire:model="category.<?php echo e($category->id); ?>">
                            <option value="">Select <?php echo e($category->name); ?></option>
                            <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>">
                                <?php echo e($list->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="distance-within-design range-design form-grouph mb-5">
                        <h5 class="h5-design">Within Distance</h5>
                        <div class="range-wrapper position-relative">
                            <p class="min-value">1 mi</p>
                            <div id="distance-range-slides" class="range-slider">
                                <div class="tooltip-range"></div>
                                <input class="range_design-input" wire:model="distance" type="range" step="1" min="0" max="100">
                            </div>
                            <p class="max-value">100 mi</p>
                        </div>
                    </div>

                    <div class="form-group input-design form-grouph icon-input-design dark-placehiolder">
                        <input type="search" wire:model.debounce.500ms="search" placeholder="Search">
                        <span class="input_icn"><i class="fa-solid fa-magnifying-glass"></i></span>
                    </div>
                </div>
            </form>
        </div>


        <div class="lawyers-list-sec">
            <div class="list-wrapper list-service">

                <?php if(count($lawyers)>0): ?>
                <?php $__currentLoopData = $lawyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-item list-service-item">
                    <div class="lawyer-hire-block">
                        <?php if(@$lawyer->profile_pic): ?>
                        <div class="lawyers-img-block">
                            <img src="<?php echo e($lawyer->profile_pic); ?>">
                        </div>
                        <?php endif; ?>
                        <div class="lawyers-service-cntnt-block">
                            <div class="lawyers-heading_service d-flex justify-content-spacebw align-items-center">
                                <h4 class="lawyer-name"><?php echo e(@$lawyer->name); ?></h4>
                                <button class="hire-price-btn">$<?php echo e(@$lawyer->details->hourly_fee); ?>/hr.</button>
                            </div>
                            <div class="lawyers-desc_service d-flex justify-content-spacebw">
                                <div class="years_experience_div">
                                    <p>YEARS EXP.</p>
                                    <h4><?php echo e(@$lawyer->details->year_experience); ?></h4>
                                </div>
                                <div class="contingency-cases_div">
                                    <p>CONTINGENCY CASES</p>
                                    <h4><?php echo e(@ucfirst($lawyer->details->contingency_cases)); ?></h4>
                                </div>
                                <div class="consult-fee_div">
                                    <p>CONSULT FEE</p>


                                    <h4><?php echo e(@$lawyer->details->is_consultation_fee=='yes' ? '$'.$lawyer->details->consultation_fee : 'Free'); ?></h4>
                                </div>
                            </div>
                            <p class="school_name"><i class="fa-solid fa-school-flag"></i><?php echo e(@$lawyer->lawyerCategory->items->name); ?></p>
                            <div class="location_profile-divs d-flex justify-content-spacebw align-items-center">
                                <address><i class="fa-solid fa-location-dot"></i> <?php echo e(@$lawyer->details->city); ?>, <?php echo e(@$lawyer->details->states->code); ?></address>
                                <a href="<?php echo e(route('lawyer.show', $lawyer->id)); ?>">See Profile</a>
                            </div>

                            <div class="add-litigations">
                                <button type="button" class="accept_btn showModal mt-2" wire:click="modalData(<?php echo e($lawyer->id); ?>)">Courts</button>
                            </div>

                            <?php $lawyerID= Crypt::encrypt($lawyer->id); ?>
                            <div class="schedular_consultation">
                                <a href="<?php echo e(route('schedule.consultation',$lawyerID)); ?>" class="schule_consultation-btn">Schedule Consultation</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p>No lawyers found</p>
                <?php endif; ?>




                <?php if($modal): ?>
                <!-- Accept Modal Start Here-->
                <div wire:ignore.self class="modal fade" id="courtModal" tabindex="-1" aria-labelledby="courtModal" aria-hidden="true">
                    <div class="modal-dialog modal_style">
                        <button type="button" class="btn btn-default close closeModal">
                            <i class="fas fa-close"></i>
                        </button>
                        <div class="modal-content">
                            <form>
                                <div class="modal-header modal_h">
                                    <h3>Courts</h3>
                                </div>
                                <div class="modal-body">
                                    <div>
                                        <?php $__currentLoopData = $modal->lawyerInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyerInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($lawyerInfo->categories->is_multiselect): ?>
                                        <div class="mb-4">
                                            <h6><?php echo e(@$lawyerInfo->items->name); ?></h6>
                                            <p class="mb-0"><?php echo e(@$lawyerInfo->items->category->name); ?> <?php echo e(@$lawyerInfo->items->category->mainCat->name ? ' - '.$lawyerInfo->items->category->mainCat->name : ''); ?></p>
                                            <div class="federal-court">
                                                <div class="form-grouph select-design">
                                                    <label>Bar Number</label>
                                                    <div><?php echo e(@$lawyerInfo->bar_number ?? '--'); ?></div>
                                                </div>
                                                <div class="form-grouph select-design">
                                                    <label>Year Admitted</label>
                                                    <div><?php echo e($lawyerInfo->year_admitted ?? '--'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Accept Modal Close Here-->
                <?php endif; ?>
                <div id="pagination-container" class="pagination-container-service"></div>
            </div>
        </div>

        <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {

                window.livewire.on('courtModalShow', () => {
                    $('#courtModal').modal('show');
                });
            });
            $(document).on('click', '.showModal', function(e) {
                $('#courtModal').modal('show');
            });
            $(document).on('click', '.closeModal', function(e) {
                $('#courtModal').modal('hide');
            });
        </script>
        <?php $__env->stopPush(); ?>
    </div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/livewire/search-lawyers.blade.php ENDPATH**/ ?>