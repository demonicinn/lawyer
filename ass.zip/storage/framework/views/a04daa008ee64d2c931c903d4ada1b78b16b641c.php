<?php $__env->startSection('content'); ?>
<section class="lawyer_conultation-wrapper-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>

        <div>
            <div class="lawyer_conultation-wrapper">
                <div class="tabs_design-wrap three_tabs-layout">
                    <div class="lawyer-tabs_lists">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link<?php echo e(request()->routeIs('consultations.upcoming') ? ' active' : ''); ?>" href="<?php echo e(route('consultations.upcoming')); ?>">Upcoming</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link<?php echo e(request()->routeIs('consultations.complete') ? ' active' : ''); ?>" href="<?php echo e(route('consultations.complete')); ?>">Complete</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link<?php echo e(request()->routeIs('consultations.accepted') ? ' active' : ''); ?>" href="<?php echo e(route('consultations.accepted')); ?>">Accepted</a>
                            </li>
                        </ul>
                    </div>


                    <div class="lawyer-tabs_contents">

                        <div class="tab-content">
                            <div id="Cases" class="container tab-pane fade active show">
                                <div class="table-responsive table-design">
                                    <table style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Email</th>
                                                <th>Date Accepted</th>
                                                <th>Details</th>
                                                <th>Phone</th>
                                                <th>Practice Area</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                            $role = 'user';
                                            if(Auth::user()->role == 'user'){
                                            $role = 'lawyer';
                                            }
                                            ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $accptedConsultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accepted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($accepted->$role->first_name); ?></td>
                                                <td><?php echo e($accepted->$role->last_name); ?></td>
                                                <td><?php echo e($accepted->$role->email); ?></td>
                                                <td><?php echo e(date('d-m-y', strtotime($accepted->updated_at))); ?></td>
                                                <td>

                                                    <a class="view-icon info_icns" href="#"><i class="fas fa-eye"></i></a>

                                                    <div class="info_icns_note_name">
                                                        <?php if(@$accepted->notes->note !=null): ?>
                                                        <?php echo e(@$accepted->notes->note); ?>


                                                        <?php endif; ?>
                                                    </div>

                                                    <?php if(Auth::user()->role=="lawyer"): ?>
                                                    <a class="edit-icons toggle_note-btn" href="#"><i class="fas fa-pen"></i></a>
                                                    <div class="note-box">
                                                        <span class="info_icns"><i class="fa-solid fa-circle-info"></i></span>
                                                        <p>Add note</p>
                                                        <div class="d-flex">
                                                            <?php if(@$accepted->notes->note !=null): ?>
                                                            <form method="post" action="<?php echo e(route('edit.note',@$accepted->notes->id)); ?>">
                                                                <?php else: ?>
                                                                <form method="post" action="<?php echo e(route('add.note',$accepted->id)); ?>">
                                                                    <?php endif; ?>

                                                                    <?php echo csrf_field(); ?>
                                                                    <textarea required name="note" class="form-control"><?php echo e(@$accepted->notes->note); ?></textarea>

                                                                    <button type="submit" class="confirm_dropdown-btn">

                                                                        <?php if(@$accepted->notes->note !=null): ?>
                                                                        Update
                                                                        <?php else: ?>
                                                                        Save
                                                                        <?php endif; ?>
                                                                    </button>
                                                                </form>
                                                                <a class="cancel_dropdown-btn cancel_btn">Cancel</a>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($accepted->$role->contact_number); ?></td>
                                                <td>Car Accident</td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <h2>No Accepted Consultation.</h2>

                                            <?php endif; ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/consultations/accepted.blade.php ENDPATH**/ ?>