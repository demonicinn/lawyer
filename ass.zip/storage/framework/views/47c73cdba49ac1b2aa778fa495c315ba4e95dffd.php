<?php $__env->startSection('content'); ?>
<section class="body-banner min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('lawyer.leaves')->html();
} elseif ($_instance->childHasBeenRendered('TR9jsHe')) {
    $componentId = $_instance->getRenderedChildComponentId('TR9jsHe');
    $componentTag = $_instance->getRenderedChildComponentTagName('TR9jsHe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TR9jsHe');
} else {
    $response = \Livewire\Livewire::mount('lawyer.leaves');
    $html = $response->html();
    $_instance->logRenderedChild('TR9jsHe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/lawyer/leave/index.blade.php ENDPATH**/ ?>