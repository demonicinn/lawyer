@extends('layouts.app')
@section('content')
<section class="body-banner narrow-down-cand-sec min-height-100vh">
    <div class="container">
        
        <div class="still-not-sure text-center">
            <p>Still not sure? Read our detailed explanation 
                <a class="pa-design" href="{{ route('narrow.down') }}">here.</a>
            </p>
        </div>

        
    </div>
</section>
@endsection