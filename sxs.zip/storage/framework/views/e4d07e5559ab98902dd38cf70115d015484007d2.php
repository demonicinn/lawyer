<?php $__env->startSection('content'); ?>
<section class="body-banner dashboard_profile-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2>Dashboard</h2>
        </div>
        <div class="dashboard_wrapper">

            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                    <div class="data-white-box position-relative">
                        <a class="data-content-box" href="<?php echo e(route('admin.lawyers.index')); ?>">
                            <h4>LAWYERS <br>AVAILABLE</h4>
                            <h2 class="number-value"><?php echo e($lawyers); ?></h2>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                    <div class="data-white-box position-relative">
                        <a class="data-content-box" href="<?php echo e(route('admin.users.index')); ?>">
                            <h4>CLIENTS <br>AVAILABLE</h4>
                            <h2 class="number-value"><?php echo e($clients); ?></h2>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                    <div class="data-white-box position-relative">
                        <a class="data-content-box" href="<?php echo e(route('admin.litigations.index')); ?>">
                            <h4>LITIGATIONS</h4>
                            <h2 class="number-value"><?php echo e($litigations); ?></h2>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                    <div class="data-white-box position-relative">
                        <a class="data-content-box" href="<?php echo e(route('admin.contracts.index')); ?>">
                            <h4>CONTRACTS</h4>
                            <h2 class="number-value"><?php echo e($contracts); ?></h2>
                        </a>
                    </div>
                </div>
            </div>

            <div class="row">


                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                    <div class="data-white-box position-relative">
                        <a class="data-content-box" href="<?php echo e(route('admin.states.index')); ?>">
                            <h4>STATES</h4>
                            <h2 class="number-value"><?php echo e($states); ?></h2>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                    <div class="data-white-box position-relative">
                        <a class="data-content-box" href="<?php echo e(route('admin.subscriptions.index')); ?>">
                            <h4>SUBSCRIPTIONS</h4>
                            <h2 class="number-value"><?php echo e($subscriptions); ?></h2>
                        </a>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                    <div class="data-white-box position-relative">
                        <a class="data-content-box" href="<?php echo e(route('admin.categories.index')); ?>">
                            <h4>CATEGORIES</h4>
                            <h2 class="number-value"><?php echo e($categories); ?></h2>
                        </a>
                    </div>
                </div>
            </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>