<?php $__env->startSection('content'); ?>
<section class="body-banner narrow-down-cand-sec min-height-100vh">
    <div class="container">
        
        <div class="still-not-sure text-center">
            <p>Still not sure? Read our detailed explanation 
                <a class="pa-design" href="<?php echo e(route('narrow.down')); ?>">here.</a>
            </p>
        </div>

        
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/home.blade.php ENDPATH**/ ?>