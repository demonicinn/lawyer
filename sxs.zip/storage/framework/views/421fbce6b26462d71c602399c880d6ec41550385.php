<?php
$days = \App\Models\User::getDays();
?>

<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
    <div class="white-shadow-scnd-box">
        <div class="form-heading">
            <h4 class="h4-design">Working Hours</h4>
        </div>

        <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $hours = $user->lawyerHours()->where('day', $day)->first();
            ?>
            <div class="custom-control custom-switch">
                <input type="checkbox" class="custom-control-input hoursDay" value="<?php echo e($day); ?>" <?php echo e(@$hours ? 'checked' : ''); ?>> <?php echo e($day); ?>

                <label class="custom-control-label"></label>
            </div>

            <div class="form-flex <?php echo e($day); ?>" style="display:<?php echo e(@$hours ? '' : 'none'); ?>">
                <div class="form-grouph input-design<?php echo ($errors->has('from_time') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('from_time','From Time*', ['class' => 'form-label']); ?>    
                    <?php echo Form::time('day['.$day.'][from_time]', @$hours->from_time ?? null, ['class' => ($errors->has('from_time') ? ' is-invalid' : '')]); ?>

                    <?php echo $errors->first('from_time', '<span class="help-block">:message</span>'); ?>

                </div>
                <div class="form-grouph input-design<?php echo ($errors->has('to_time') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('to_time','To Time*', ['class' => 'form-label']); ?>    
                    <?php echo Form::time('day['.$day.'][to_time]', @$hours->to_time ?? null, ['class' => ($errors->has('to_time') ? ' is-invalid' : '')]); ?>

                    <?php echo $errors->first('to_time', '<span class="help-block">:message</span>'); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/lawyer/profile/hours.blade.php ENDPATH**/ ?>