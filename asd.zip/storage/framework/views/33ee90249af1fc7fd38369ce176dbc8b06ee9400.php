<?php $__env->startSection('content'); ?>
<section class="body-banner min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.categories')->html();
} elseif ($_instance->childHasBeenRendered('dlkaTQF')) {
    $componentId = $_instance->getRenderedChildComponentId('dlkaTQF');
    $componentTag = $_instance->getRenderedChildComponentTagName('dlkaTQF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dlkaTQF');
} else {
    $response = \Livewire\Livewire::mount('admin.categories');
    $html = $response->html();
    $_instance->logRenderedChild('dlkaTQF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>