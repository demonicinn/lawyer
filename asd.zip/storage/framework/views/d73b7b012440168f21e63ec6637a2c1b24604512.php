<?php $__env->startSection('content'); ?>
	
	<input type="hidden" id="zoom_id" value="<?php echo e(@$booking->zoom_id); ?>">
	<input type="hidden" id="zoom_zak" value="<?php echo e(@$booking->zoom_zak); ?>">
	<input type="hidden" id="user_name" value="<?php echo e($user->name); ?>">
	<input type="hidden" id="user_email" value="<?php echo e($user->email); ?>">

	<div id="zoom_conference"></div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.jsx'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/common/zoom.blade.php ENDPATH**/ ?>