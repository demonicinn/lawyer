<?php $__env->startSection('content'); ?>
<section class="body-banner portal-inner-page-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>


        <div class="">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div>
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('consultations.upcoming')); ?>">Upcoming Consultations</a>
                            <p><?php echo e($upcomingConsultations); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div>
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('consultations.complete')); ?>">Completed Consultations</a>
                            <p><?php echo e($completeConsultations); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div>
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('consultations.accepted')); ?>">Accepted Consultations</a>
                            <p><?php echo e($acceptedConsultations); ?></p>
                        </div>
                    </div>
                </div>
            </div>


            <?php echo Form::open(['method'=>'get']); ?>

            <div class="row py-4">
                <div class="col-md-2 form-group">
                    <input type="number" class="form-control" name="year" value="<?php echo e($year = request()->year ?? date('Y')); ?>" min="2022" max="<?php echo e(date('Y')); ?>" required>
                </div>

                <div class="col-md-1 form-group">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>

            </div>
            <?php echo Form::close(); ?>




            <div id="bookingChart"></div>
        </div>


    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"
type="text/javascript"></script>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css"
rel="Stylesheet"type="text/css"/>



<script type="text/javascript">
    // Load google charts
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(bookingChart);

    <?php
    $months=array('01'=>'Jan', '02'=>'Feb', '03'=>'Mar', '04'=>'Apr', '05'=>'May', '06'=>'June', '07'=>'July', '08'=>'Aug', '09'=>'Sep', '10'=>'Oct', '11'=>'Nov', '12'=>'Dec');
    ?>


    function bookingChart() {
        
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Month');
        data.addColumn('number', 'Bookings');
        
        data.addRows([
        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            ['<?php echo e($month); ?>', <?php echo e(getBookingsCount($k, $year)); ?>],
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);

        
        var options = {
            hAxis: {
                title: 'Months'
            },
            vAxis: {
                title: 'Number of Bookings'
            },
            seriesType: 'bars',
            series: {1: {type: 'line'}},
            tooltip: { isHtml: true },
            legend: { position: 'top' }
        };
        
        var chart = new google.visualization.ComboChart(document.getElementById('bookingChart'));
        chart.draw(data, options);
    }


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/lawyer/dashboard/index.blade.php ENDPATH**/ ?>