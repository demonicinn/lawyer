<?php $__env->startSection('content'); ?>
<section class="lawyer_conultation-wrapper-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>

        <div>
            <div class="lawyer_conultation-wrapper">
                <div class="tabs_design-wrap three_tabs-layout">

                    <?php echo $__env->make('pages.consultations.tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="lawyer-tabs_contents">
                        <div class="tab-content">
                            <div id="Upcoming" class="container tab-pane active">

                                <div class="table-responsive table-design">
                                    <table style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Practice Area</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $role = 'user';
                                            if(Auth::user()->role == 'user'){
                                            $role = 'lawyer';
                                            }
                                            ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $upcomingConsultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcoming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                            <?php
                                            $start_time=date('g:i A', strtotime($upcoming->booking_time));
                                            $end_time=date('g:i A', strtotime($upcoming->booking_time. ' +30 minutes'));
                                            ?>
                                            <tr>
                                                <td><?php echo e($upcoming->$role->first_name); ?></td>
                                                <td><?php echo e($upcoming->$role->last_name); ?></td>
                                                <td>Car Accident</td>
                                                <td><?php echo e(date('d-m-y', strtotime($upcoming->booking_date))); ?></td>
                                                <td><?php echo e($start_time); ?> - <?php echo e($end_time); ?></td>
                                                <td>
                                                    <div class="dropdown reshedule_dropdowns">
                                                        <button class="toggle_cstm-btn" type="button">Reshedule</button>

                                                        <?php if(Auth::user()->role == 'user'): ?>

                                                        <div class="reshedule_wrap-box">
                                                            <span class="info_icns"><i class="fa-solid fa-circle-info"></i></span>
                                                            <p>Resheduling consultation will hurt your ratings</p>
                                                            <div class="d-flex">
                                                                <a href="<?php echo e(route('reschedule.booking',$upcoming->id)); ?>" class="accept_btn showModal">Confirm</a>

                                                                <a class="cancel_dropdown-btn cancel_btn">Cancel</a>
                                                            </div>
                                                        </div>

                                                        <?php else: ?>

                                                        <div class="reshedule_wrap-box">
                                                            <span class="info_icns"><i class="fa-solid fa-circle-info"></i></span>
                                                            <p>Resheduling consultation will hurt your ratings</p>
                                                            <div class="d-flex">
                                                                <a href="<?php echo e(route('reschedule.booking',$upcoming->id)); ?>" class="accept_btn showModal">Confirm</a>

                                                                <a class="cancel_dropdown-btn cancel_btn">Cancel</a>
                                                            </div>
                                                        </div>

                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tfoot>
                                            <tr>
                                                <td colspan="6" class="text-center pt-3">
                                                    <h4>No consultations found</h4>
                                                </td>
                                            </tr>
                                        </tfoot>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/consultations/upcoming.blade.php ENDPATH**/ ?>