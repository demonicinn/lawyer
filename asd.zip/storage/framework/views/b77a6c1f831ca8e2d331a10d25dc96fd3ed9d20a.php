<?php $__env->startSection('content'); ?>
<section class="body-banner narrow-down-cand-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center">
            <h2>Let’s narrow down the candidates…</h2>
            <p>What do you need your attorney to do?</p>
        </div>
        <div class="narrow-down-rows">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="narrow-box position-relative">
                        <div class="narrow-icon-box">
                            <img src="assets/images/litigations.svg">
                        </div>
                        <h4>Litigation</h4>
                        <p>Argue on your behalf in court or in front of an arbitrator</p>
                        <a class="link-overlay" href="<?php echo e(route('narrow.litigations')); ?>"></a>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="narrow-box position-relative">
                        <div class="narrow-icon-box">
                            <img src="assets/images/contracts.svg">
                        </div>
                        <h4>Contracts</h4>
                        <p>Draft or review personal, business, or real estate contracts</p>
                        <a class="link-overlay" href="<?php echo e(route('narrow.contracts')); ?>"></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="still-not-sure text-center">
            <p>Still not sure? Read our detailed explanation <a class="pa-design" href="#">here.</a></p>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/narrowDown.blade.php ENDPATH**/ ?>