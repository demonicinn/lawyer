<?php $__env->startSection('content'); ?>
<section class="body-banner min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('reschedule-booking',['bookingId' => $bookingId])->html();
} elseif ($_instance->childHasBeenRendered('w2A23Ak')) {
    $componentId = $_instance->getRenderedChildComponentId('w2A23Ak');
    $componentTag = $_instance->getRenderedChildComponentTagName('w2A23Ak');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('w2A23Ak');
} else {
    $response = \Livewire\Livewire::mount('reschedule-booking',['bookingId' => $bookingId]);
    $html = $response->html();
    $_instance->logRenderedChild('w2A23Ak', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/reschedule.blade.php ENDPATH**/ ?>