<?php

$user = auth()->user();

?>

<header id="header">
  <div class="container-1340px">
    <div class="header-wrapper">
      <div class="logo-left-column">
        <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>"></a>
      </div>
      <div class="login-right-column">
        <?php if(auth()->guard()->guest()): ?>
        <!-- <div class="login_signup-btns dropdown">
        <button type="button" class="dropdown-toggle login-header-btn" data-bs-toggle="dropdown">
            <span class="drop-icon"><i class="fa-solid fa-angle-down"></i></span>
            <span class="user-span">login</span>
            <span class="user-icon"><img class="header-pic" src="<?php echo e(asset('assets/images/sample-img.png')); ?>"></span> 
          </button>
          <ul class="dropdown-menu p-3">
          <a class="dropdown-item btn_sign_up mb-3" href="<?php echo e(route('register')); ?>">Sign Up</a>
          <a class="dropdown-item btn_login" href="<?php echo e(route('login')); ?>">Login</a>
          </ul>
        </div> -->
        <a class="login-header-btn btn_sign_up mb-3 me-3 py-3" href="<?php echo e(route('register')); ?>">Sign Up</a>
          <a class="login-header-btn btn_login py-3" href="<?php echo e(route('login')); ?>">Login</a>
        <?php else: ?>
        <div class="dropdown">
          <button type="button" class="dropdown-toggle login-header-btn" data-bs-toggle="dropdown">
            <span class="drop-icon"><i class="fa-solid fa-angle-down"></i></span>
            <span class="user-span"><?php echo e($user->name); ?></span>
            <span class="user-icon"><img class="header-pic" src="<?php echo e($user->profile_pic); ?>"></span>
          </button>
          <ul class="dropdown-menu">
            <?php if(Auth::user()->role=="admin"): ?>
            <li><a class="dropdown-item" href="<?php echo e(route($user->role)); ?>">Dashboard</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('admin.profile')); ?>">My profile</a></li>
            <?php elseif(Auth::user()->role=="lawyer"): ?>
            <li><a class="dropdown-item" href="<?php echo e(route($user->role)); ?>">Dashboard</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('lawyer.profile')); ?>">My profile</a></li>
            
            

            <li><a class="dropdown-item" href="<?php echo e(route('lawyer.subscription')); ?>">Subscription</a></li>

            <?php else: ?>
            <li><a class="dropdown-item" href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>">My profile</a></li>
            <?php endif; ?>
            <?php if(Auth::user()->role=="user" || Auth::user()->role=="lawyer"): ?>
            <li><a class="dropdown-item" href="<?php echo e(route('consultations.upcoming')); ?>">Consultations</a></li>
            <?php endif; ?>
            <li><a class="dropdown-item" href="<?php echo e(route('change.password')); ?>">Change password</a></li>
            <li>
              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
              </form>
            </li>


          </ul>
        </div>
        <?php endif; ?>

      </div>


    </div>
  </div>
</header><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/layouts/includes/header.blade.php ENDPATH**/ ?>