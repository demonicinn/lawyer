<?php $__env->startSection('content'); ?>
<section class="body-banner user_account-info-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        <div class="user_acc_info-wrapper">


            

            <?php echo Form::open(['route' => ['review.store', encrypt($booking->id)], 'class'=>' form-design']); ?>

            <div class="white-shadow-scnd-box">
                <div class="form-flex">

                    <div class="col-md-6">
                        <div class="list-item list-service-item">
                            <div class="lawyer-hire-block">
                                <div class="lawyers-img-block">
                                    <img src="<?php echo e($booking->lawyer->profile_pic); ?>">
                                </div>
                                <div class="lawyers-service-cntnt-block">
                                    <div class="lawyers-heading_service d-flex justify-content-spacebw align-items-center">
                                        <h4 class="lawyer-name"><?php echo e($booking->lawyer->name); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-grouph input-design<?php echo ($errors->has('rating') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('rating', 'Did the lawyer show up to the consultation', ['class' => 'form-label']); ?>

                            <div id="rateYo"></div>
                            <input type="hidden" name="rating" value="">
                            <?php echo $errors->first('rating', '<span class="help-block">:message</span>'); ?>

                        </div>

                        <div class="form-grouph input-design<?php echo ($errors->has('comment') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('comment', 'Comment', ['class' => 'form-label']); ?>

                            <?php echo Form::textarea('comment', null, ['placeholder'=>'Leave Comment', 'class' => ($errors->has('comment') ? ' is-invalid' : '')]); ?>

                            <?php echo $errors->first('comment', '<span class="help-block">:message</span>'); ?>

                        </div>
                    </div>

                </div>
            </div>
            <div class="row mt-3">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
                    <div class="form-grouph submit-design text-center">
                        <button type="submit" class="btn-design-second">Submit</button>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>

<script>
    $(document).ready(function() {
        $("#rateYo").rateYo({
            starWidth: "40px",
            onSet: function (rating, rateYoInstance) {
                $('input[name=rating]').val(rating);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/user/review/index.blade.php ENDPATH**/ ?>