<?php $__env->startSection('content'); ?>
<section class="lawyer_conultation-wrapper-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>

        <div>
            <div class="lawyer_conultation-wrapper">
                <div class="tabs_design-wrap three_tabs-layout">

                    <?php echo $__env->make('pages.consultations.tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="lawyer-tabs_contents">

                        <div class="tab-content">
                            <div id="Complete" class="container tab-pane fade active show">
                                <div class="table-responsive table-design">
                                    <table style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>First Name</th>
                                                <th>Last Name</th>
                                                <th>Practice Area</th>
                                                <th>Date</th>
                                                <th>Details</th>
                                                <?php if(Auth::user()->role == "lawyer"): ?>
                                                <th>Action</th>
                                                <?php endif; ?>

                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php
                                            $role = 'user';
                                            if(Auth::user()->role == 'user'){
                                            $role = 'lawyer';
                                            }
                                            ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $completeConsultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($complete->$role->first_name); ?></td>
                                                <td><?php echo e($complete->$role->last_name); ?></td>
                                                <td>Car Accident</td>
                                                <td><?php echo e(date('d-m-y', strtotime($complete->booking_date))); ?></td>
                                                <td>
                                                    <a class="view-icon info_icns" href="#"><i class="fas fa-eye"></i></a>

                                                    <div class="info_icns_note_name">
                                                        <?php if(@$complete->notes->note !=null): ?>
                                                        <?php echo e(@$complete->notes->note); ?>


                                                        <?php endif; ?>
                                                    </div>

                                                    <?php if(Auth::user()->role == "lawyer"): ?>
                                                    <a class="edit-icons toggle_note-btn" href="#"><i class="fas fa-pen"></i></a>

                                                    <div class="note-box">
                                                        <span class="info_icns"><i class="fa-solid fa-circle-info"></i></span>
                                                        <p>Add note</p>
                                                        <div class="d-flex">
                                                            <?php if(@$complete->notes->note !=null): ?>
                                                            <form method="post" action="<?php echo e(route('edit.note',@$complete->notes->id)); ?>">
                                                                <?php else: ?>
                                                                <form method="post" action="<?php echo e(route('add.note',$complete->id)); ?>">
                                                                    <?php endif; ?>

                                                                    <?php echo csrf_field(); ?>
                                                                    <textarea required name="note" class="form-control"><?php echo e(@$complete->notes->note); ?></textarea>

                                                                    <button type="submit" class="confirm_dropdown-btn">

                                                                        <?php if(@$complete->notes->note !=null): ?>
                                                                        Update
                                                                        <?php else: ?>
                                                                        Save
                                                                        <?php endif; ?>
                                                                    </button>
                                                                    <a class="cancel_dropdown-btn cancel_btn">Cancel</a>
                                                                </form>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                </td>

                                                <?php if(Auth::user()->role == "lawyer"): ?>
                                                <td>
                                                    <form method="post" action="<?php echo e(route('accept.case',$complete->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="accept_btn">Accept</button>
                                                    </form>

                                                    <form method="post" action="<?php echo e(route('decline.case',$complete->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="decline-btn">Decline</button>
                                                    </form>
                                                </td>
                                                <?php endif; ?>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <tfoot>
                                            <tr>
                                                <td colspan="6" class="text-center pt-3">
                                                    <h4>No consultations found</h4>
                                                </td>
                                            </tr>
                                        </tfoot>

                                        <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>


                        </div>

                    </div>



                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/consultations/completed.blade.php ENDPATH**/ ?>