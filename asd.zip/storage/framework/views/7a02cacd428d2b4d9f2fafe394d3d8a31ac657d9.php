<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
	


<img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" class="logo" alt="<?php echo e($slot); ?>">

</a>
</td>
</tr>
<?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>