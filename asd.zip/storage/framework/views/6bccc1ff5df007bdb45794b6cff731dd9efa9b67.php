<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('schedule-consultation', ['lawyerID' => $lawyerID])->html();
} elseif ($_instance->childHasBeenRendered('lak9WiC')) {
    $componentId = $_instance->getRenderedChildComponentId('lak9WiC');
    $componentTag = $_instance->getRenderedChildComponentTagName('lak9WiC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lak9WiC');
} else {
    $response = \Livewire\Livewire::mount('schedule-consultation', ['lawyerID' => $lawyerID]);
    $html = $response->html();
    $_instance->logRenderedChild('lak9WiC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/schedule-consultation.blade.php ENDPATH**/ ?>