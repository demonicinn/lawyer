<?php $__env->startSection('content'); ?>
<?php
$states = \App\Models\State::whereStatus('1')->pluck('name', 'id');
?>
<section class="body-banner authentication-sec min-height-100vh signup-sec">
	<div class="container">
		<div class="authentication-container">
			<div class="authentication-header">
				<h2>Lawyer Sign Up</h2>
			</div>
			<div class="lawyer-login">
				<?php echo Form::open(['route' => 'register', 'method'=>'post', 'class'=>'form-design']); ?>

				<div class="white-shadow-box">
					<div class="form-flex">

						<div class="form-grouph input-design<?php echo ($errors->has('first_name') ? ' has-error' : ''); ?>">
							<?php echo Form::label('first_name','First Name*', ['class' => 'form-label']); ?>

							<?php echo Form::text('first_name', null, ['class' => ($errors->has('first_name') ? ' is-invalid' : '')]); ?>

							<?php echo $errors->first('first_name', '<span class="help-block">:message</span>'); ?>

						</div>
						<div class="form-grouph input-design<?php echo ($errors->has('last_name') ? ' has-error' : ''); ?>">
							<?php echo Form::label('last_name','Last Name*', ['class' => 'form-label']); ?>

							<?php echo Form::text('last_name', null, ['class' => ($errors->has('last_name') ? ' is-invalid' : '')]); ?>

							<?php echo $errors->first('last_name', '<span class="help-block">:message</span>'); ?>

						</div>
						<div class="form-grouph input-design<?php echo ($errors->has('email') ? ' has-error' : ''); ?>">
							<?php echo Form::label('email','Email*', ['class' => 'form-label']); ?>

							<?php echo Form::email('email', null, ['class' => ($errors->has('email') ? ' is-invalid' : '')]); ?>

							<?php echo $errors->first('email', '<span class="help-block">:message</span>'); ?>

						</div>
						<div class="form-grouph input-design<?php echo ($errors->has('city') ? ' has-error' : ''); ?>">
							<?php echo Form::label('city','City*', ['class' => 'form-label']); ?>

							<?php echo Form::text('city', null, ['class' => ($errors->has('city') ? ' is-invalid' : '')]); ?>

							<?php echo $errors->first('city', '<span class="help-block">:message</span>'); ?>

						</div>
						<div class="form-grouph select-design<?php echo ($errors->has('state') ? ' has-error' : ''); ?>">
							<?php echo Form::label('state','State', ['class' => 'form-label']); ?>

							<?php echo Form::select('state', $states, null, ['class' => ($errors->has('state') ? ' is-invalid' : ''), 'placeholder'=>'Select State']); ?>

							<?php echo $errors->first('state', '<span class="help-block">:message</span>'); ?>

						</div>
						<div class="form-grouph input-design<?php echo ($errors->has('zip_code') ? ' has-error' : ''); ?>">
							<?php echo Form::label('zip_code','Zip Code', ['class' => 'form-label']); ?>

							<?php echo Form::text('zip_code', null, ['class' => ($errors->has('zip_code') ? ' is-invalid' : '')]); ?>

							<?php echo $errors->first('zip_code', '<span class="help-block">:message</span>'); ?>

						</div>
						<div class="form-grouph input-design<?php echo ($errors->has('password') ? ' has-error' : ''); ?>">
							<?php echo Form::label('password','Password', ['class' => 'form-label']); ?>

							<input type="password" id="password" name="password" class="<?php echo ($errors->has('password') ? ' is-invalid' : ''); ?>" />
							<?php echo $errors->first('password', '<span class="help-block">:message</span>'); ?>

						</div>
						<div class="form-grouph input-design<?php echo ($errors->has('password') ? ' has-error' : ''); ?>">
							<?php echo Form::label('password_confirmation','Confirm Password', ['class' => 'form-label']); ?>

							<input type="password" id="password_confirmation" name="password_confirmation" class="<?php echo ($errors->has('password') ? ' is-invalid' : ''); ?>" />
							<?php echo $errors->first('password_confirmation', '<span class="help-block">:message</span>'); ?>

						</div>
					</div>
					<div class="form-flex">
						<div class="form-grouph input-design<?php echo ($errors->has('term') ? ' has-error' : ''); ?>">
							<input type="checkbox" id="term" name="term" class="<?php echo ($errors->has('term') ? ' is-invalid' : ''); ?>" />Accept the privacy policy and Terms & Conditions.
							<?php echo $errors->first('term', '<div class="help-block">:message</div>'); ?>

						</div>
					</div>
					<div class="form-grouph submit-design text-center">
						<button class="form-btn" type="submit">Get Started</button>
					</div>
					<div class="account-availblity-div text-center">
						<p class="mb-3">Already have an account? <a href="<?php echo e(route('login')); ?>">Login</a></p>
						<p>Looking for a lawyer? <a href="<?php echo e(route('home')); ?>">Click here</a></p>
					</div>
				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/auth/register.blade.php ENDPATH**/ ?>