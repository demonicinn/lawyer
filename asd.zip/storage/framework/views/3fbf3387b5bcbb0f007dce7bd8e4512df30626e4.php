<div>
    <section class="body-banner schdule-consultation-page-sec min-height-100vh">
        <div class="container">
            <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-4">
                <h2>Schedule a Consultation</h2>
            </div>

            <div class="schedule_consultation-wrapper">
                <form class="schedule-form-design">
                    <div class="row">

                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                            <div wire:ignore class="calendar-container">
                                <div id="celender"></div>
                            </div>

                            <?php echo $errors->first('selectDate', '<span class="help-block">:message</span>'); ?>

                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                            <div id="events-data">
                                <h4 class="event-date">
                                    <p><?php echo e($dateFormat); ?></p>
                                </h4>
                                <?php if($workingDatesTimeSlot): ?>
                           
                                <ul class="list-unstyled">

                                    <?php $__currentLoopData = $workingDatesTimeSlot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>

                                        <div class="time-selection">
                                            <input type="radio" <?php $__currentLoopData = $is_booking_exits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(($exit->booking_time== date('H:i:s', strtotime($time))) ? 'disabled' : ''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="<?php echo e(date('h:i A', strtotime($time))); ?>" wire:model="selectDateTimeSlot">
                                            <button class="time-selection-btn" <?php $__currentLoopData = $is_booking_exits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(($exit->booking_time== date('H:i:s', strtotime($time))) ? 'disabled' : ''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                                <i class="fa-regular fa-calendar-check"></i><?php echo e(date('h:i A', strtotime($time))); ?>

                                            </button>
                                        </div>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php echo $errors->first('selectDateTimeSlot', '<span class="help-block">:message</span>'); ?>

                                <?php else: ?>
                                <h5>Oops! Slot not available.</h5>
                                <?php endif; ?>

                            </div>
                        </div>
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
                            <div class="form-grouph submit-design text-center">
                                <button type="button" class="btn-design-first" wire:loading.remove wire:click="confirmSlot" wire:loading.attr="disabled">
                                    Confirm
                                </button>

                                <button type="button" wire:loading wire:target="confirmSlot" class="btn-design-first">
                                    <i class="fa fa-spin fa-spinner"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>




    <script>
        let workingDates = <?php echo json_encode(@$workingDates, 15, 512) ?>;

        $(document).ready(function() {

            getDates(workingDates);

            window.livewire.on('fireCalender', (dates) => {
                getDates(dates);
            });
        });


        function getDates(workingDates) {
            let newEvents = [];

            $.each(workingDates, function(i, date) {
                var map = [];
                map['startDate'] = date;
                map['endDate'] = date;

                //...
                newEvents.push(map);
            });

            //...
            initCalender(newEvents)
        }

        function initCalender(eventArray) {

            var container = $("#celender").simpleCalendar({
                //fixedStartDay: 0, // begin weeks by sunday
                disableEmptyDetails: true,
                disableEventDetails: true,
                enableOnlyEventDays: true,

                onMonthChange: function(month, year) {
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('month', month + 1);
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('year', year);
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectDate', '');
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectDateTimeSlot', '');
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('dateFormat', '');
                },

                onDateSelect: function(date, events) {


                    var dateF = new Date(date);
                    let newDate = (dateF.getMonth() + 1) + '/' + dateF.getDate() + '/' + dateF.getFullYear();

                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectDate', newDate);
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectDateTimeSlot', '');
                },

            });


            let $calendar = container.data('plugin_simpleCalendar')
            //reinit events
            $calendar.setEvents(eventArray)
        }

        $(document).ready(function() {
            window.livewire.on('loginFormClose', () => {
                $('#loginForm').modal('hide');
            });

        });
    </script>

    <style>
        .day.wrong-month {
            display: none;
        }
    </style>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/livewire/reschedule-booking.blade.php ENDPATH**/ ?>