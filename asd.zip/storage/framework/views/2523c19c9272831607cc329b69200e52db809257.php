<?php $__env->startSection('content'); ?>
<section class="body-banner portal-inner-page-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        <div class="">
            <div class="row justify-content-center">
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12">
                    <div class="portal-div-design position-relative">
                        <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div>
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('consultations.upcoming')); ?>">Upcoming Consultations</a>
                            <p><?php echo e($upcomingConsultations); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-sm-12">
                    <div class="portal-div-design position-relative">
                        <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div>
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('consultations.complete')); ?>">Completed Consultations</a>
                            <p><?php echo e($completeConsultations); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-sm-12">
                    <div class="portal-div-design position-relative">
                        <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div>
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('consultations.accepted')); ?>">Accepted Consultations</a>
                            <p><?php echo e($acceptedConsultations); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/user/dashboard/index.blade.php ENDPATH**/ ?>