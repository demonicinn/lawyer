<div>

    <?php if(@$currentTab=='tab1'): ?>
    <?php echo $__env->make('livewire.consultation.time-slot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if(@$currentTab=='tab2'): ?>
    <?php echo $__env->make('livewire.consultation.booking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


    <?php $__env->startPush('scripts'); ?>

    <script>
        let workingDates = <?php echo json_encode(@$workingDates, 15, 512) ?>;

        $(document).ready(function() {

            $(document).on('click', '.loginModalShow', function(){
                $('#loginForm').modal('show');
            });
            $(document).on('click', '.closeLoginModal', function(){
                $('#loginForm').modal('hide');
            });

            getDates(workingDates);

            window.livewire.on('fireCalender', (dates) => {
                getDates(dates);
            });
            window.livewire.on('loginFormClose', () => {
                $('#loginForm').modal('hide');
            });
            window.livewire.on('unCheckRadiobtn', () => {

                $('.checkedbtn').prop('checked', false);
                window.livewire.find('<?php echo e($_instance->id); ?>').set('paymentDetails', true);
               
            });
            window.livewire.on('scrollUp', () => {
                $(window).scrollTop(0);
            });

        });


        function getDates(workingDates) {
            let newEvents = [];

            $.each(workingDates, function(i, date) {
                var map = [];
                map['startDate'] = date;
                map['endDate'] = date;

                //...
                newEvents.push(map);
            });

            //...
            initCalender(newEvents)
        }

        function initCalender(eventArray) {

            var container = $("#celender").simpleCalendar({
                //fixedStartDay: 0, // begin weeks by sunday
                disableEmptyDetails: true,
                disableEventDetails: true,
                enableOnlyEventDays: true,

                onMonthChange: function(month, year) {
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('month', month + 1);
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('year', year);
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectDate', '');
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectDateTimeSlot', '');
                },

                onDateSelect: function(date, events) {

                    var dateF = new Date(date);
                    let newDate = (dateF.getMonth() + 1) + '/' + dateF.getDate() + '/' + dateF.getFullYear();

                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectDate', newDate);
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectDateTimeSlot', '');
                },

            });


            let $calendar = container.data('plugin_simpleCalendar')
            //reinit events


            $calendar.setEvents(eventArray)


            console.log('fcdfcdx', $calendar)
        }

    </script>

    <style>
        .day.wrong-month {
            display: none;
        }
        
        .loading {
            position: fixed;
            width: 100%;
            height: 100%;
            content: "";
            background-color: #9d9b9bad;
            top: 0;
        }

        .loader {
            border: 6px solid #f3f3f3;
            border-top: 6px solid #ff0000;
            border-radius: 50%;
            width: 56px;
            height: 56px;
            animation: spin 2s linear infinite;
            position: fixed;
            z-index: 999;
            margin: auto;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH /home/texasbutchersmal/public_html/resources/views/livewire/schedule-consultation.blade.php ENDPATH**/ ?>