<div class="form-group">
    <input type="search" wire:model="search" placeholder="Search">

</div>
<div id="Upcoming" class="container tab-pane active">
    <div class="table-responsive table-design">
        <table style="width:100%" id="laravel_datatable">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Practice Area</th>
                    <th>Date</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $role = 'user';
                if(Auth::user()->role == 'user'){
                $role = 'lawyer';
                }
                ?>

                <?php if(count($upcomingConsul)>0): ?>
                <?php $__currentLoopData = $upcomingConsul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcoming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($upcoming->$role->first_name); ?></td>
                    <td><?php echo e($upcoming->$role->last_name); ?></td>
                    <td>Car Accident</td>
                    <td><?php echo e(date('d-m-y', strtotime($upcoming->booking_date))); ?></td>
                    <td><?php echo e(date('g:i A', strtotime($upcoming->booking_time))); ?> - <?php echo e(date('g:i A', strtotime($upcoming->booking_time. ' +30 minutes'))); ?> </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
            <tfoot>
                <tr>
                    <td colspan="6" class="text-center pt-3">
                        <h4>No consultations found</h4>
                    </td>
                </tr>
            </tfoot>
            <?php endif; ?>

            </tbody>
        </table>
    </div>

</div><?php /**PATH /home/texasbutchersmal/public_html/resources/views/livewire/admin/consultation/upcoming.blade.php ENDPATH**/ ?>