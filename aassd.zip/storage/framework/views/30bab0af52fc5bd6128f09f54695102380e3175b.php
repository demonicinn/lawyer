<?php $__env->startSection('content'); ?>
<section class="body-banner min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('reschedule-booking',['bookingId' => $bookingId])->html();
} elseif ($_instance->childHasBeenRendered('bLet6vM')) {
    $componentId = $_instance->getRenderedChildComponentId('bLet6vM');
    $componentTag = $_instance->getRenderedChildComponentTagName('bLet6vM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bLet6vM');
} else {
    $response = \Livewire\Livewire::mount('reschedule-booking',['bookingId' => $bookingId]);
    $html = $response->html();
    $_instance->logRenderedChild('bLet6vM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/reschedule.blade.php ENDPATH**/ ?>