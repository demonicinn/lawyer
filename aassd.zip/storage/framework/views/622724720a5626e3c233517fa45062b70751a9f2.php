<?php $__env->startSection('content'); ?>
<section class="body-banner lawyer-directory-profile-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2>Directory Profile</h2>
            <a href="<?php echo e(url()->previous() ?? route('narrow.down')); ?>" class="go-back"><i class="fa-solid fa-arrow-left-long"></i> Back to Lawyers</a>
        </div>
        <div class="directory-profile-wrapper">
            <form class="directory-form-information form-design">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                        <div class="white-shadow-third-box">
                            <div class="lawyer-hire-block">
                                <div class="lawyers-img-block">
                                    <img src="<?php echo e($user->profile_pic); ?>">
                                </div>
                                <div class="lawyers-service-cntnt-block">
                                    <div class="lawyers-heading_service d-block justify-content-spacebw align-items-center directory_h4_btn">
                                        <h4 class="lawyer-name text-center"><?php echo e(@$user->name); ?></h4>
                                        <button class="hire-price-btn">$<?php echo e(@$user->details->hourly_fee); ?>/hr.</button>
                                    </div>
                                    <div class="lawyers-desc_service d-flex justify-content-spacebw">
                                        <div class="years_experience_div">
                                            <p>YEARS EXP.</p>
                                            <h4><?php echo e(@$user->details->year_experience); ?></h4>
                                        </div>
                                        <div class="contingency-cases_div">
                                            <p>CONTINGENCY CASES</p>
                                            <h4><?php echo e(@ucfirst($user->details->contingency_cases)); ?></h4>
                                        </div>
                                        <div class="consult-fee_div">
                                            <p>CONSULT FEE</p>
                                            <h4><?php echo e(@$user->details->is_consultation_fee=='yes' ? '$'.$user->details->consultation_fee : 'Free'); ?></h4>
                                        </div>
                                    </div>
                                    <p class="school_name"><i class="fa-solid fa-school-flag"></i> Harvard Law School</p>
                                    <div class="location_profile-divs school_name border-bottom px-0 pb-2">
                                        <address><i class="fa-solid fa-location-dot"></i> <?php echo e(@$user->details->city); ?>, <?php echo e(@$user->details->states->code); ?></address>
                                    </div>

                                    <div class="add-litigations mt-2 location_profile-divs d-flex justify-content-spacebw align-items-center ">
                                <button type="button" class="btn_court showModal "><i class="fa-solid fa-gavel"></i>  Courts</button>
                              <!--   <a href="#">See Profile</a> -->
                            </div>


                                    <!-- <div class="add-litigations">
                                        <button type="button" class="accept_btn showModal mt-2">Courts</button>
                                    </div> -->

                                    <?php $lawyerID= Crypt::encrypt($user->id); ?>

                                    <?php if(auth()->check()): ?>
                                    <?php if(auth()->user()->role=='user'): ?>
                                    <div class="schedular_consultation">
                                        <a href="<?php echo e(route('schedule.consultation', $lawyerID)); ?>?type=<?php echo e(request()->type); ?>&search=<?php echo e(request()->search); ?>" class="schule_consultation-btn">Schedule Consultation</a>
                                    </div>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <div class="schedular_consultation">
                                        <a href="<?php echo e(route('schedule.consultation', $lawyerID)); ?>?type=<?php echo e(request()->type); ?>&search=<?php echo e(request()->search); ?>" class="schule_consultation-btn">Schedule Consultation</a>
                                    </div>
                                    <?php endif; ?>


                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12">
                        <div class="white-shadow-third-box lawyer-directory_about-block">
                            <div class="grey-light-heading">
                                <h4>About <?php echo e(@$user->name); ?></h4>
                            </div>
                            <div class="lawyer_profile-description">
                                <?php echo @$user->details->bio; ?>


                                <?php if(Auth::check()): ?>
                                    <?php
                                        $savedLawyer = auth()->user()->savedLawyer->pluck('lawyer_id')->toArray();
                                        //dd($savedLawyer);
                                    ?>
                                    <?php if(in_array($user->id, $savedLawyer)): ?>
                                    <div class="save_btn text-center">
                                        <a href="<?php echo e(route('user.lawyer.remove', $lawyerID)); ?>" class="btn-design-first" title="Already Saved">Remove Attorney</a>
                                    </div>
                                    <?php else: ?>
                                    <div class="save_btn text-center">
                                        <a href="<?php echo e(route('user.save.lawyer',$lawyerID)); ?>" class="btn-design-first">Save Attorney</a>
                                    </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                <div class="save_btn text-center">
                                    <a href="<?php echo e(route('login')); ?>?redirect=true" class="btn-design-first">Save Attorney</a>
                                </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<div class="modal fade courts_modal common_modal" id="courtModal" tabindex="-1" aria-labelledby="courtModal" aria-hidden="true">
    <div class="modal-dialog modal_style">
        <button type="button" class="btn btn-default close closeModal">
            <i class="fas fa-close"></i>
        </button>
        <div class="modal-content">
            <form>
                <div class="modal-header modal_h">
                    <h3>Courts</h3>
                </div>
                <div class="modal-body">
                    <div>
                        <?php $__currentLoopData = $user->lawyerInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyerInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lawyerInfo->categories->is_multiselect): ?>
                        <div class="mb-4 courts_data">
                           <div class="name_data_p">
                             <h6><?php echo e(@$lawyerInfo->items->name); ?></h6>
                            <p class="mb-0"><?php echo e(@$lawyerInfo->items->category->name); ?> <?php echo e(@$lawyerInfo->items->category->mainCat->name ? ' - '.$lawyerInfo->items->category->mainCat->name : ''); ?></p>
                           </div>
                            <div class="federal-court">
                                <div class="form-grouph select-design">
                                    <label>Bar Number</label>
                                    <div><?php echo e(@$lawyerInfo->bar_number ?? '--'); ?></div>
                                </div>
                                <div class="form-grouph select-design">
                                    <label>Year Admitted</label>
                                    <div><?php echo e($lawyerInfo->year_admitted ?? '--'); ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $('.showModal').on('click', function(){
        $('#courtModal').modal('show');
    });
    $('.closeModal').on('click', function(){
        $('#courtModal').modal('hide');
    });



</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/pages/lawyers-show.blade.php ENDPATH**/ ?>