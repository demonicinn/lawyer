<div>

    <div class="add-search-box">
        <div class="form-group">
            <input wire:model="search" class="form-control search-box" type="text" placeholder="Search">
        </div>
    </div>
    <div class="table-responsive table-design">
        <table style="width:100%">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact Number</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lawyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($lawyer->name); ?></td>
                    <td><?php echo e($lawyer->email); ?></td>
                    <td><?php echo e($lawyer->contact_number); ?></td>
                    <td>
                        <?php if(@$lawyer->details->is_verified=='yes'): ?>
                        <button type="button" class="accept_btn">Active</button>
                        <?php else: ?>
                        <button type="button" class="decline-btn">In-active</button>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(@$lawyer->details->review_request=='1' && $lawyer->details->is_verified=='no'): ?>

                        <button type="button" class="btn btn-sm btn-success" wire:click="review('<?php echo e($lawyer->id); ?>', 'accept')">Accept</button>
                        <button type="button" class="btn btn-sm btn-danger" wire:click="review('<?php echo e($lawyer->id); ?>', 'declined')">Declined</button>
                        <a href="<?php echo e(route('admin.laywer.view',$lawyer->id)); ?>">
                            <button type="button" class="btn btn-sm btn-info "><i class="fa fa-eye" aria-hidden="true"></i></button>
                        </a>
                        <?php endif; ?>
                        
                        

                        <a href="<?php echo e(route('admin.laywer.view',$lawyer->id)); ?>">
                            <button type="button" class="btn btn-sm btn-info "><i class="fa fa-eye" aria-hidden="true"></i></button>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div id="pagination-container" class="pagination-container-saved"><?php echo e($lawyers->links()); ?></div>
</div><?php /**PATH /home/texasbutchersmal/public_html/resources/views/livewire/admin/lawyers.blade.php ENDPATH**/ ?>