<?php $__env->startSection('content'); ?>
<section class="body-banner portal-inner-page-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>


        <div class="">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <!-- <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div> -->
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('consultations.upcoming')); ?>">Consultations</a>
                            <p><?php echo e($upcomingConsultations); ?></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div>

                <!-- <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div>
                        <div class="portal-cntnt-wrapper">
                            <a href="#">Dashboard</a>
                            <p></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div> -->

            

                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <!-- <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div> -->
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('lawyer.profile')); ?>">Account</a>
                            <p></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <!-- <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div> -->
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('support')); ?>">Support</a>
                            <p></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div>

            </div>

           <div class="row">
            <div class="col-md-12">
            <div class="data-white-box no-hover-box">
            <div class="heading-design-flex d-flex justify-content-spacebw align-items-center">
                  <h4>BOOKINGS BY MONTH</h4>
                  <?php echo Form::open(['method'=>'get']); ?>

            <div class="form-char-flext">
                <div class="form-group input-design">
                    <input type="number" class="form-control" name="year" value="<?php echo e($year = request()->year ?? date('Y')); ?>" min="2022" max="<?php echo e(date('Y')); ?>" required>
                </div>
                <div class="form-group submit-design">
                    <button class="btn btn-primary" style="background-color: #f93f64; border-color:#f93f64;" type="submit">Search</button>
                </div>
            </div>
            <?php echo Form::close(); ?>

                </div>
            <div id="bookingChart"></div>
            </div>
            </div>
           </div>
        </div>


    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"
type="text/javascript"></script>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css"
rel="Stylesheet"type="text/css"/>



<script type="text/javascript">
    // Load google charts
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(bookingChart);

    <?php
    $months=array('01'=>'JAN', '02'=>'FEB', '03'=>'MAR', '04'=>'APR', '05'=>'MAY', '06'=>'JUN', '07'=>'JUL', '08'=>'AUG', '09'=>'SEP', '10'=>'OCT', '11'=>'NOV', '12'=>'DEC');
    ?>


    function bookingChart() {
        
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Months');
        data.addColumn('number', 'Bookings by Months');
        
        data.addRows([
        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            ['<?php echo e($month); ?>', <?php echo e(getBookingsCount($k, $year)); ?>],
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);

        
        var options = {
            hAxis: {
                title: '',
                gridlines: {
                  color: 'transparent'
                },
                textStyle: {
            fontSize: 10,
            color: '#979797'
            }
            },
            vAxis: {
                title: '',
                gridlines: {
                  color: 'transparent'
                },
                textStyle: {
            fontSize: 10,
            color: '#979797'
            }
            },
            seriesType: 'bars',
            series: {1: {type: 'line'}},
            tooltip: { isHtml: true },
            legend: { position: 'none' },
            colors: ['#f93f64'],
            chartArea: {'width': '85%'},
            is3D: true,
            backgroundColor: {
                'fill': 'transparent',
                'stroke': 'transparent',
                'strokeWidth': '0',
            },
            annotations: {
            textStyle: {
            fontSize: 10,
            color: '#979797'
            }
        }
        };
        
        var chart = new google.visualization.ComboChart(document.getElementById('bookingChart'));
        chart.draw(data, options);
    }


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/lawyer/dashboard/index.blade.php ENDPATH**/ ?>