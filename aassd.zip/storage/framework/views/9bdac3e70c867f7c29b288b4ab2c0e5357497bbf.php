
<div class="lawyer_profile-wrapper">
    <div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
		    <div class="white-shadow-scnd-box">
		        <div class="form-heading">
		            <h4 class="h4-design">Bank Details</h4>
		        </div> 

		        <?php if(!$user->bankInfo): ?>
					<?php echo Form::open(['route' => 'lawyer.bank.connect', 'class'=>'lawyer_profile-information form-design']); ?>


					<button type="submit" class="btn-design-first btn_bank">Connect Bank Account</button>

					<?php echo Form::close(); ?>

				<?php else: ?>
					<?php
						$bankInfo = $user->bankInfo;
					?>
					<b>Your Account is Connected.</b>
					<p><strong>Account Holder Name:</strong> <?php echo e(@$bankInfo->account_holder_name); ?></p>
					<p><strong>Account Number:</strong> <?php echo e(@$bankInfo->account_number); ?></p>
					<p><strong>Routing Number:</strong> <?php echo e(@$bankInfo->routing_number); ?></p>

					<a href="<?php echo e(route('lawyer.banking.success')); ?>" class="btn-design-first btn_bank">Edit Bank Account</a>
  				<?php endif; ?>
		    </div>
		</div>
    </div>
</div><?php /**PATH /home/texasbutchersmal/public_html/resources/views/lawyer/profile/bank_info.blade.php ENDPATH**/ ?>