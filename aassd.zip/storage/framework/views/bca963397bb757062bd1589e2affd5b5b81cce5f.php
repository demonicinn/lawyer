<?php $__env->startSection('content'); ?>


<section class="body-banner dashboard_profile-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-3">
            <h2>Account Information</h2>
        </div>
        <div class="user_acc_info-wrapper">
            
            <?php if(@$record): ?>
                <?php if(@$bankInfo->status=='active'): ?>
                    <?php if(!$record->account_number): ?>
                        <p class="text-center pb-3">Please fill the bank account to complete your bank account verification.</p>
                    <?php endif; ?>
                    <form class="form-design row justify-content-center" method="post" action="<?php echo e(route('lawyer.banking.store')); ?>">
                        <?php echo csrf_field(); ?>
        
                        <div class="col-md-7">
                        <div class="white-shadow-scnd-box ">
                            <div class="form">
                                <div class="form-grouph input-design">
                                    <label>Account Holder Name*</label>
                                    <input class="<?php $__errorArgs = ['account_holder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="account_holder_name" value="<?php echo e(@$record->account_holder_name); ?>">
                                    <?php $__errorArgs = ['account_holder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="help-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-grouph input-design">
                                    <label>Account Number*</label>
                                    <input class="<?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="account_number" value="<?php echo e(@$record->account_number); ?>">
                                    <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="help-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-grouph input-design">
                                    <label>Routing Number*</label>
                                    <input class="<?php $__errorArgs = ['routing_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="routing_number" value="<?php echo e(@$record->routing_number); ?>">
                                    <?php $__errorArgs = ['routing_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="help-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
        
                            </div>
                        </div>
                        </div>
                        <div class="col-12 mt-3">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
                                <div class="form-grouph submit-design text-center">
                                    
                                    <input type="submit" value="<?php echo e(@$record->account_number ? 'Edit' : 'Add'); ?> Account" class="btn-design-second">
                                    
                                </div>
                            </div>
                        </div>
                    </form>
                <?php else: ?>
                    <?php echo Form::open(['route' => 'lawyer.bank.connect', 'class'=>'form-design row justify-content-center']); ?>

        			<button type="submit" class="btn-design-first btn_bank">Connect Bank Account</button>
        			<?php echo Form::close(); ?>

                <?php endif; ?>
            <?php else: ?>
                <?php echo Form::open(['route' => 'lawyer.bank.connect', 'class'=>'form-design row justify-content-center']); ?>

    			<button type="submit" class="btn-design-first btn_bank">Connect Bank Account</button>
    			<?php echo Form::close(); ?>

            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/lawyer/profile/account.blade.php ENDPATH**/ ?>