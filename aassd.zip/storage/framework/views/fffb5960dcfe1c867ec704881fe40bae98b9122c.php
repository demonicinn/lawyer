<div>
    <div class="form-grouph view_practice-area">
        <button type="button" class="btn-design-second showModal">Select Practice areas</button>
    </div>



    <div wire:ignore.self class="modal fade show in" id="practiceModal" tabindex="-1" role="dialog" aria-labelledby="practiceModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                <div class="modal-body">
                    <div class="heading-paragraph-design text-center position-relative go-back-wrap">
                        <h2>Areas of Practice</h2>
                        <p>Edit or change practice areas</p>
                    </div>
                    <div class="tabs_design-wrap two_tabs-layout">
                        <div class="area_practice_lists">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e($currentTab=='litigations' ? 'active' : ''); ?>" href="javascript:void(0)" wire:click="setCurrentTab('litigations')">Litigation</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e($currentTab=='contracts' ? 'active' : ''); ?>" href="javascript:void(0)" wire:click="setCurrentTab('contracts')">Transactional</a>
                                </li>
                            </ul>
                        </div>
                        <div class="area_practice_fields">
                            <form class="form-design">
                                <div class="tab-content">
                                    
                                    <?php if($currentTab=='litigations'): ?>
                                    <div id="litigations" class="container tab-pane active">
                                        <div class="row">
                                            
                                            <?php
                                                $count = count($litigations) / 2;
                                                $count = number_format($count);
                                            ?>

                                            <?php $__currentLoopData = $litigations->chunk($count); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6">
                                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j =>  $litigation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-grouph checkbox-design position-relative">
                                                    <input type="checkbox" value="<?php echo e($litigation->id); ?>" wire:model="selectLitigations.<?php echo e($j); ?>">
                                                    <button class="checkbox-btn"></button>
                                                    <label><?php echo e(@$litigation->name); ?></label>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php echo $errors->first('selectLitigations', '<span class="help-block">:message</span>'); ?>

                                    </div>
                                    <?php endif; ?>

                                    <?php if($currentTab=='contracts'): ?>
                                    <div id="contracts" class="container tab-pane active"><br>
                                        <div class="row">
                                            <?php
                                                $countCon = count($contracts) / 2;
                                                $countCon = number_format($countCon);
                                            ?>

                                            <?php $__currentLoopData = $contracts->chunk($countCon); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6">
                                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="form-grouph checkbox-design position-relative">
                                                        <input type="checkbox" value="<?php echo e($contract->id); ?>" wire:model="selectContracts.<?php echo e($i); ?>">
                                                        <button class="checkbox-btn"></button>
                                                        <label><?php echo e(@$contract->name); ?></label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php echo $errors->first('selectContracts', '<span class="help-block">:message</span>'); ?>

                                    </div>
                                    <?php endif; ?>

                                    <div class="text-center mt-5">
                                        <div class="form-grouph submit-design text-center">
                                            <button type="button" class="btn-design-first" wire:click="store" wire:loading.attr="disabled">
                                                <i wire:loading wire:target="store" class="fa fa-spin fa-spinner"></i> Save
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            window.livewire.on('practiceFormModalHide', () => {
                $('#practiceModal').modal('hide');
            });
        });

        $(document).on('click', '.showModal', function(e) {
            $('#practiceModal').modal('show');
        });
        $(document).on('click', '.closeModal', function(e) {
            $('#practiceModal').modal('hide');
        });
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/livewire/lawyer/practice-areas.blade.php ENDPATH**/ ?>