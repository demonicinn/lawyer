<div>

    <div class="user_saved-lawyers_inner">
        <div class="user-saved_filter-sec pb-5">
            <form class="form-design">
                <div class="d-flex justify-content-spacebw">
                    <div class="form-grouph select-design select-design-2 d-flex">
                        <label>Practice:</label>
                        <select wire:model="practiceArea">
                            <option value="" selected>Practice Area</option>
                            <option value="Litigations">Litigations</option>
                            <option value="Contracts">Contracts</option>
                        </select>

                    </div>

                    <?php if(!empty($practices)): ?>
                    <div class="form-grouph select-design select-design-2 d-flex">
                        <label>Area:</label>
                        <select wire:model="areaId">
                            <option value="" selected disabled><?php echo e($practiceArea); ?></option>
                            <?php $__currentLoopData = $practices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($practice->id); ?>"><?php echo e($practice->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>

                  <div class="d-flex justify-content-center"> 
                    <div class="form-grouph input-design icon-input-design right-icn-design">
                        <input type="search" wire:model="search" placeholder="Search">
                        <span class="input_icn"><i class="fa-solid fa-magnifying-glass"></i></span>
                    </div>
                    <div class="form-grouph input-design icon-input-design right-icn-design mt-1">
                        <a class="btn clear-btn" wire:click="clear">Clear</a>
                    </div>
                  </div>

                </div>
            </form>

        </div>

        <div class="user_saved-lawyers_list">
            <div class="list-wrapper list-wrapper-saved four-layout">


                <?php $__empty_1 = true; $__currentLoopData = $lawyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="list-item list-item-saved">
                    <div class="lawyer-hire-block">
                        <div class="lawyers-img-block">
                            <img src="<?php echo e($lawyer->lawyer->profile_pic); ?>">
                        </div>
                        <div class="lawyers-service-cntnt-block">
                            <div class="lawyers-heading_service d-flex justify-content-spacebw align-items-center">
                                <h4 class="lawyer-name"><?php echo e($lawyer->lawyer->first_name); ?> <?php echo e($lawyer->lawyer->last_name); ?></h4>
                                <button class="hire-price-btn">$<?php echo e($lawyer->lawyer->details->hourly_fee); ?>/hr.</button>

                            </div>
                            <div class="lawyers-desc_service d-flex justify-content-spacebw">
                                <div class="years_experience_div">
                                    <p>YEARS EXP.</p>
                                    <h4><?php echo e($lawyer->lawyer->details->year_experience); ?></h4>
                                </div>
                                <div class="contingency-cases_div">
                                    <p>CONTINGENCY CASES</p>
                                    <h4><?php echo e($lawyer->lawyer->details->contingency_cases); ?></h4>
                                </div>
                                <div class="consult-fee_div">
                                    <p>CONSULT FEE</p>
                                    <h4>$<?php echo e($lawyer->lawyer->details->consultation_fee); ?></h4>
                                </div>
                            </div>
                            <p class="school_name"><i class="fa-solid fa-school-flag"></i><?php echo e(@$lawyer->lawyerCategory->items->name); ?></p>
                            <div class="location_profile-divs d-flex justify-content-spacebw align-items-center">
                                <address><i class="fa-solid fa-location-dot"></i> <?php echo e(@$lawyer->lawyer->details->city); ?>, <?php echo e(@$lawyer->lawyer->details->states->code); ?></address>
                                <a href="<?php echo e(route('lawyer.show', $lawyer->lawyer->id)); ?>?type=<?php echo e($lawyer->type); ?>&search=<?php echo e($lawyer->data); ?>">See Profile</a>
                            </div>
                            <?php $lawyerID= Crypt::encrypt($lawyer->lawyer->id); ?>


                            <div class="add-litigations">
                                <button type="button" class="btn_court showModal mt-2" wire:click="modalData(<?php echo e($lawyer->lawyer->id); ?>)"><i class="fa-solid fa-gavel"></i> Admission</button>
                            </div>
                            <div class="schedular_consultation">

                                <a href="<?php echo e(route('schedule.consultation',$lawyerID)); ?>?type=<?php echo e($lawyer->type); ?>&search=<?php echo e($lawyer->data); ?>" class="schule_consultation-btn">Schedule Consultation</a>
                            </div>
                            <?php
                                $tdate = date('Y-m-d');

                                $date2week = \Carbon\Carbon::parse($tdate)->add(14, 'days')->format('Y-m-d');

                                $checkAv = $lawyer->lawyer->leave()->where('date', '>=', $tdate)
                                        ->where('date', '<=', $date2week)
                                        ->count();

                            ?>
                            <?php if(@$checkAv=='14'): ?>
                            <p class="alt info">This lawyer is not available within two weeks</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4>No Lawyers Found</h4>
                <?php endif; ?>


            </div>
        </div>

        <?php if($modal): ?>
        <!-- Accept Modal Start Here-->
        <div wire:ignore.self class="modal fade courts_modal common_modal modal-design" id="courtModal" tabindex="-1" aria-labelledby="courtModal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                <button type="button" class="btn btn-default close closeModal">
                    <i class="fas fa-close"></i>
                </button>
                    <form>
                        <div class="modal-header modal_h">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                              <?php if($modal->lawyerInfo): ?>
                              <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Federal Court Admissions</button>
                              </li>
                              <?php endif; ?>

                              <?php if($modal->lawyerStateBar): ?>
                              <li class="nav-item" role="presentation">
                                <button class="nav-link <?php echo e(!$modal->lawyerInfo ? 'active' : ''); ?>" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">State Bar Admissions</button>
                              </li>
                              <?php endif; ?>
                            </ul>
                        </div>
                        <div class="modal-body">
                            
                            <div class="tab-content" id="myTabContent">
                                    <?php if($modal->lawyerInfo): ?>
                                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <?php $__currentLoopData = $modal->lawyerInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawyerInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-4 courts_data">
                                           <div class="name_data_p">
                                             <h6><?php echo e(@$lawyerInfo->items->name); ?></h6>
                                            <p class="mb-0"><?php echo e(@$lawyerInfo->items->category->name); ?> <?php echo e(@$lawyerInfo->items->category->mainCat->name ? ' - '.$lawyerInfo->items->category->mainCat->name : ''); ?></p>
                                           </div>
                                            <div class="federal-court">
                                                <div class="form-grouph select-design">
                                                    <label>Bar Number</label>
                                                    <div><?php echo e(@$lawyerInfo->bar_number ?? '--'); ?></div>
                                                </div>
                                                <div class="form-grouph select-design">
                                                    <label>Year Admitted</label>
                                                    <div><?php echo e($lawyerInfo->year_admitted ?? '--'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($modal->lawyerStateBar): ?>
                                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                        <?php $__currentLoopData = $modal->lawyerStateBar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-4 courts_data">
                                           <div class="name_data_p">
                                             <h6><?php echo e(@$item->statebar->name); ?></h6>
                                           </div>
                                            <div class="federal-court">
                                                <div class="form-grouph select-design">
                                                    <label>Bar Number</label>
                                                    <div><?php echo e(@$item->bar_number ?? '--'); ?></div>
                                                </div>
                                                <div class="form-grouph select-design">
                                                    <label>Year Admitted</label>
                                                    <div><?php echo e($item->year_admitted ?? '--'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Accept Modal Close Here-->
        <?php endif; ?>

        <div id="pagination-container" class="pagination-container-saved"><?php echo e($lawyers->links()); ?></div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {

            window.livewire.on('courtModalShow', () => {
                $('#courtModal').modal('show');
            });
        });
        $(document).on('click', '.showModal', function(e) {
            $('#courtModal').modal('show');
        });
        $(document).on('click', '.closeModal', function(e) {
            $('#courtModal').modal('hide');
        });
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/livewire/user/saved-lawyers.blade.php ENDPATH**/ ?>