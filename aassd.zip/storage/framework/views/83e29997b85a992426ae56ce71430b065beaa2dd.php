<?php $__env->startSection('content'); ?>
<section class="body-banner portal-inner-page-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        <div class="">
            <div class="row justify-content-center">
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <!-- <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div> -->
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('consultations.upcoming')); ?>">Consultations</a>
                            <p><?php echo e($upcomingConsultations); ?></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <!-- <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div> -->
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('user.saved.lawyer')); ?>">Saved Lawyers</a>
                            <p></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <!-- <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div> -->
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('user.profile')); ?>">Account</a>
                            <p></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div>
            </div>
                <div class="row justify-content-center">
                <div class="col-xl-3 col-lg-3 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <!-- <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div> -->
                        <div class="portal-cntnt-wrapper">
                            <a href="#">Billing</a>
                            <p></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-sm-12 mb-3">
                    <div class="portal-div-design position-relative">
                        <!-- <div class="portal-div-img">
                            <img src="<?php echo e(asset('assets/images/schedule.svg')); ?>">
                        </div> -->
                        <div class="portal-cntnt-wrapper">
                            <a href="<?php echo e(route('support')); ?>">Support</a>
                            <p></p>
                        </div>
                        <span class="three_dots">...</span>
                    </div>
                </div>

            </div>
        </div>


    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/user/dashboard/index.blade.php ENDPATH**/ ?>