<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('schedule-consultation', ['lawyerID' => $lawyerID])->html();
} elseif ($_instance->childHasBeenRendered('rEb3Q2D')) {
    $componentId = $_instance->getRenderedChildComponentId('rEb3Q2D');
    $componentTag = $_instance->getRenderedChildComponentTagName('rEb3Q2D');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rEb3Q2D');
} else {
    $response = \Livewire\Livewire::mount('schedule-consultation', ['lawyerID' => $lawyerID]);
    $html = $response->html();
    $_instance->logRenderedChild('rEb3Q2D', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/pages/schedule-consultation.blade.php ENDPATH**/ ?>