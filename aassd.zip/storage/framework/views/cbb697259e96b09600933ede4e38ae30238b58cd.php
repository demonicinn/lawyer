<?php $__env->startSection('content'); ?>
<section class="user_saved-lawyers-sec">
      <div class="container">
         <div class="heading-paragraph-design text-center position-relative mb-4">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.saved-lawyers')->html();
} elseif ($_instance->childHasBeenRendered('hGgE0Dt')) {
    $componentId = $_instance->getRenderedChildComponentId('hGgE0Dt');
    $componentTag = $_instance->getRenderedChildComponentTagName('hGgE0Dt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hGgE0Dt');
} else {
    $response = \Livewire\Livewire::mount('user.saved-lawyers');
    $html = $response->html();
    $_instance->logRenderedChild('hGgE0Dt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/user/saved-lawyer.blade.php ENDPATH**/ ?>