<?php $__env->startSection('script'); ?>
<link type="text/css" rel="stylesheet" href="https://source.zoom.us/2.7.0/css/bootstrap.css" />
<link type="text/css" rel="stylesheet" href="https://source.zoom.us/2.7.0/css/react-select.css" />

<script src="https://source.zoom.us/2.7.0/lib/vendor/react.min.js"></script>
<script src="https://source.zoom.us/2.7.0/lib/vendor/react-dom.min.js"></script>
<script src="https://source.zoom.us/2.7.0/lib/vendor/redux.min.js"></script>
<script src="https://source.zoom.us/2.7.0/lib/vendor/redux-thunk.min.js"></script>
<script src="https://source.zoom.us/2.7.0/lib/vendor/lodash.min.js"></script>
<script src="https://source.zoom.us/zoom-meeting-2.7.0.min.js"></script>
<script src="<?php echo e(asset('meeting/tool.js')); ?>"></script>
<script src="<?php echo e(asset('meeting/vconsole.min.js')); ?>"></script>
<script src="<?php echo e(asset('meeting/meeting.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/common/zoom_meet.blade.php ENDPATH**/ ?>