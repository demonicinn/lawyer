<?php $__env->startSection('content'); ?>
<section class="lawyer-services-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-4">
            <h2>Lawyers that provide<br> these services</h2>
            <a href="<?php echo e(route($route)); ?>" class="go-back"><i class="fa-solid fa-arrow-left-long"></i> Back to Practice Area</a>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-lawyers')->html();
} elseif ($_instance->childHasBeenRendered('vDnLZah')) {
    $componentId = $_instance->getRenderedChildComponentId('vDnLZah');
    $componentTag = $_instance->getRenderedChildComponentTagName('vDnLZah');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vDnLZah');
} else {
    $response = \Livewire\Livewire::mount('search-lawyers');
    $html = $response->html();
    $_instance->logRenderedChild('vDnLZah', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>


<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>

<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">



<style>
    .slider-box {width: 90%; margin: 25px auto}
label, input {border: none; display: inline-block; margin-right: -4px; vertical-align: top; width: 30%}
input {width: 70%}
.slider {margin: 25px 0}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/pages/lawyers.blade.php ENDPATH**/ ?>