<div class="lawyer-tabs_lists">
    <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item">
            <a class="nav-link<?php echo e(request()->routeIs('consultations.upcoming') ? ' active' : ''); ?>" href="<?php echo e(route('consultations.upcoming')); ?>">Upcoming</a>
        </li>
        <li class="nav-item">
            <a class="nav-link<?php echo e(request()->routeIs('consultations.complete') ? ' active' : ''); ?>" href="<?php echo e(route('consultations.complete')); ?>">Completed</a>
        </li>
        <li class="nav-item">
            <a class="nav-link<?php echo e(request()->routeIs('consultations.accepted') ? ' active' : ''); ?>" href="<?php echo e(route('consultations.accepted')); ?>">Accepted</a>
        </li>
    </ul>
</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/consultations/tabs.blade.php ENDPATH**/ ?>