<?php $__env->startSection('content'); ?>
<section class="body-banner dashboard_profile-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
            <a href="<?php echo e(route('user.billing.index')); ?>" class="go-back"><i class="fa-solid fa-arrow-left-long"></i> Go Back</a>
        </div>

        
        <div class="user_payment-wrapper-inner">

          <?php echo Form::open(['route' => 'user.billing.store', 'class'=>' form-design']); ?>

            <div class="white-shadow-scnd-box">
              <div class="form-heading">
                <h4 class="h4-design">Billing Information</h4>
              </div>
              <div class="billing-info_form-inputs">

              	<div class="form-grouph input-design<?php echo ($errors->has('card_name') ? ' has-error' : ''); ?>">
	                <?php echo Form::label('card_name', 'Name on Card', ['class' => 'form-label']); ?>

	                <?php echo Form::text('card_name', null, ['class' => ($errors->has('card_name') ? ' is-invalid' : '')]); ?>

	                <?php echo $errors->first('card_name', '<span class="help-block">:message</span>'); ?>

	            </div>

	            <div class="form-grouph input-design<?php echo ($errors->has('card_number') ? ' has-error' : ''); ?>">
	                <?php echo Form::label('card_number', 'Card Numbe', ['class' => 'form-label']); ?>

	                <?php echo Form::number('card_number', null, ['class' => ($errors->has('card_number') ? ' is-invalid' : '')]); ?>

	                <?php echo $errors->first('card_number', '<span class="help-block">:message</span>'); ?>

	            </div>



	            <div class="form-flex three-columns">
                    <div class="form-grouph input-design">
                        <label>Expiration Month</label>
                        <select name="expire_month" class="form-control" placeholder="Exp Month">
                            <option value="">Select Month</option>
                            <?php for($i = 1; $i <=12; $i++): ?>
                            <option value="<?php echo e($i<=9 ? '0'.$i : $i); ?>"><?php echo e(date('F', mktime(0,0,0,$i))); ?></option>
                            <?php endfor; ?>
                        </select>
                        <?php echo $errors->first('expire_month', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph input-design">
                        <label>Expiration Year</label>
                        <select name="expire_year" class="form-control" placeholder="Expiration Year">
                            <option value="">Select Year</option>
                            <?php for($i = 0; $i <10; $i++): ?>
                            <?php $year = date('Y') + $i; ?>
                            <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                            <?php endfor; ?>
                        </select>
                        <?php echo $errors->first('expire_year', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph input-design">
                        <label>CVV</label>
                        <input type="number" placeholder="CVV" name="cvv">
                        <?php echo $errors->first('cvv', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>



                </div>
            </div>
          <div class="row mt-3">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
              <div class="form-grouph submit-design text-center">
                <input type="submit" value="Add Payment Information" class="btn-design-third">
              </div>
            </div>
          </div>
          </form>
        </div>


      
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/user/billing/create.blade.php ENDPATH**/ ?>