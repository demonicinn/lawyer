<?php $__env->startSection('content'); ?>
<section class="body-banner thanks_booking-sec min-height-100vh " style="background-image: url('<?php echo e(asset('assets/images/home-banner.png')); ?>');">
  <div class="container">
  <div class="white-shadow-third-box">
         <div class="heading-paragraph-design text-center mb-5">
          <h2>Thank you for your booking</h2>
         </div>
        <div class="booking-info_profile-flex">
          <div class="booking-info-left_column">
             <img src="<?php echo e($booking->lawyer->profile_pic); ?>">
          </div>
          <div class="booking-info-right_column">
             <h4 class="booking_name"><?php echo e($booking->lawyer->name); ?></h4>
             <h5 class="booking_type-text">Admiralty/Maritime</h5>
             <p class="booking_date-time"><?php echo e(date('l, F d Y', strtotime($booking->booking_date))); ?> <span class="divider-horizonatl"></span> <?php echo e(date('H:i a', strtotime($booking->booking_time))); ?></p>
         </div>
        </div>
      </div>
      <div class="row mt-3">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
          <div class="text-center">
            <a href="<?php echo e(route('home')); ?>" class="btn-design-first">Go Back Home</a>
          </div>
        </div>
      </div>

      
  </div>
 </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/pages/thankYou.blade.php ENDPATH**/ ?>