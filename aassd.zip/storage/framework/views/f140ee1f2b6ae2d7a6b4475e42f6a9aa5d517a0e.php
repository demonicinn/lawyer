<?php $__env->startSection('content'); ?>
<section class="body-banner user_account-info-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        <div class="user_acc_info-wrapper">
            <?php echo Form::open(['route' => 'user.profile.update', 'class'=>' form-design']); ?>

            <div class="white-shadow-scnd-box">
                <div class="form-flex">
                    <div class="form-grouph input-design<?php echo ($errors->has('first_name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('first_name','First Name*', ['class' => 'form-label']); ?>

                        <?php echo Form::text('first_name', $user->first_name ?? null, ['placeholder'=>'First Name', 'class' => ($errors->has('first_name') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('first_name', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph input-design<?php echo ($errors->has('last_name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('last_name','Last Name*', ['class' => 'form-label']); ?>

                        <?php echo Form::text('last_name', $user->last_name ?? null, ['placeholder'=>'Last Name', 'class' => ($errors->has('last_name') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('last_name', '<span class="help-block">:message</span>'); ?>

                    </div>
                 
                    <div class="form-grouph input-design<?php echo ($errors->has('email') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('email','Email*', ['class' => 'form-label']); ?>

                        <?php echo Form::email('email', $user->email ?? null, ['placeholder'=>'Email', 'class' => ($errors->has('email') ? ' is-invalid' : ''), 'disabled']); ?>

                        <?php echo $errors->first('email', '<span class="help-block">:message</span>'); ?>

                    </div>
                   
                    <div class="form-grouph input-design<?php echo ($errors->has('contact_number') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('contact_number','Phone*', ['class' => 'form-label']); ?>

                        <?php echo Form::number('contact_number', $user->contact_number ?? null, ['placeholder'=>'Phone', 'class' => ($errors->has('contact_number') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('contact_number', '<span class="help-block">:message</span>'); ?>

                    </div>
                 

                </div>
            </div>
            <div class="row mt-3">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
                    <div class="form-grouph submit-design text-center">
                        <input type="submit" value="Update" class="btn-design-second">
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/user/profile/index.blade.php ENDPATH**/ ?>