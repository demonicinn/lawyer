<?php $__env->startSection('content'); ?>
<section class="lawyer_conultation-wrapper-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>

        <div>
            <div class="lawyer_conultation-wrapper">
                <div class="tabs_design-wrap three_tabs-layout">

                    <?php echo $__env->make('pages.consultations.tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="lawyer-tabs_contents">

                        <div class="tab-content">
                            <div id="Complete" class="container tab-pane fade active show">
                                <div class="table-responsive table-design">
                                    <table style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Practice Area</th>
                                                <th>Date</th>
                                                <th>Details</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php
                                            $role = 'user';
                                            if(Auth::user()->role == 'user'){
                                            $role = 'lawyer';
                                            }
                                            ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $completeConsultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($complete->$role->first_name); ?> <?php echo e($complete->$role->last_name); ?></td>
                                                <td>
                                                    <?php if($complete->search_data): ?>
                                                    <?php
                                                        $search = json_decode($complete->search_data);
                                                    ?>
                                                        <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($complete->search_type == 'litigations'): ?>
                                                            <?php echo e(litigationsData($id)); ?>

                                                            <?php else: ?>
                                                            <?php echo e(contractsData($id)); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(date('m-d-Y', strtotime($complete->booking_date))); ?></td>
                                                <td>
                                                    <?php if(@$complete->notes->note != null): ?>
                                                    <a class="view-icon info_icns mdl" href="javascript:void(0)" data-id="myNoteModal_<?php echo e($complete->id); ?>" data-type="view"><i class="fas fa-eye"></i></a>
                                                    <?php endif; ?>

                                                    <?php if(Auth::user()->role=="lawyer"): ?>
                                                    <a class="view-icon info_icns mdl" href="javascript:void(0)" data-id="myNoteModal_<?php echo e($complete->id); ?>" data-type="edit"><i class="fas fa-edit"></i></a>
                                                    <?php endif; ?>

                                                    <div id="myNoteModal_<?php echo e($complete->id); ?>" class="modal fade common_modal  noteModal" role="dialog">
                                                    
                                                      <div class="modal-dialog">
                                                      <button type="button" class="btn btn-default close cloaseModal">  <i class="fas fa-close"></i></button>
                                                        <!-- Modal content-->
                                                        <div class="modal-content">
                                                          <div class="modal-header modal_h">
                                                            <h3 class="modal-title">Notes</h3>
                                                          </div>




                                                          <?php if(Auth::user()->role=="lawyer"): ?>
                                                            <?php if(@$complete->notes->note != null): ?>
                                                            <form method="post" action="<?php echo e(route('edit.note',@$complete->notes->id)); ?>">
                                                            <?php else: ?>
                                                            <form method="post" action="<?php echo e(route('add.note',$complete->id)); ?>">
                                                            <?php endif; ?>

                                                            <?php echo csrf_field(); ?>

                                                              <div class="modal-body">
                                                                
                                                                <?php if(@$complete->notes->note !=null): ?>
                                                                <div class="view"><?php echo e(@$complete->notes->note); ?></div>
                                                                <?php endif; ?>

                                                                <div class="edit">
                                                                <textarea required name="note" class="form-control"><?php echo e(@$complete->notes->note); ?></textarea>
                                                            </div>

                                                              </div>
                                                              <div class="modal-footer">
                                                                <button type="submit" class="   btn-design-first edit">
                                                                    <?php if(@$complete->notes->note !=null): ?>
                                                                    Update
                                                                    <?php else: ?>
                                                                    Save
                                                                    <?php endif; ?>
                                                                </button>

                                                                    <button type="button" class="btn btn-default cloaseModal">Close</button>
                                                                </div>
                                                                </form>

                                                          <?php else: ?>

                                                          <div class="modal-body">
                                                                
                                                                <?php if(@$complete->notes->note !=null): ?>
                                                                <p><?php echo e(@$complete->notes->note); ?></p>
                                                                <?php endif; ?>

                                                              </div>

                                                            <div class="modal-footer">
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-default cloaseModal">Close</button>
                                                                </div>
                                                            </div>
                                                          <?php endif; ?>
                                                        </div>

                                                      </div>
                                                    </div>
                                                </td>

                                                <td class="form_td">
                                                    <?php if($complete->is_canceled=='1'): ?>
                                                        <button type="submit" class="decline-btn">Canceled</button>
                                                    <?php else: ?>
                                                    <?php if(Auth::user()->role == "lawyer"): ?>
                                                    <form method="post" action="<?php echo e(route('accept.case', $complete->id)); ?>" class="">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="accept_btn">Accept</button>
                                                    </form>

                                                    <form method="post" action="<?php echo e(route('decline.case', $complete->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="decline-btn">Decline</button>
                                                    </form>
                                                    <?php else: ?>
                                                    <form method="post" action="<?php echo e(route('cancel.case', $complete->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="decline-btn">Cancel</button>
                                                    </form>
                                                    <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <tfoot>
                                            <tr>
                                                <td colspan="6" class="text-center pt-3">
                                                    <h4>No consultations found</h4>
                                                </td>
                                            </tr>
                                        </tfoot>

                                        <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>


                        </div>

                    </div>



                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
<script>

</script>
<script>
$('.info_icns.mdl').on('click', function (){
    var id = $(this).attr('data-id');
    var type = $(this).attr('data-type');

    $('#'+id).modal('show');


    $('#'+id+' .view').hide();
    $('#'+id+' .edit').hide();

    $('#'+id+' .'+type).show();

});


$('.cloaseModal').on('click', function (){
    $('.noteModal').modal('hide');
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/pages/consultations/completed.blade.php ENDPATH**/ ?>