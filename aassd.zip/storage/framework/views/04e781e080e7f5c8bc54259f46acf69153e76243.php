<div class="col-md-12 col-sm-12 mt-3">
    <div class="white-shadow-third-box">
        <h2><?php echo e(@$title['title']); ?> Consultations</h2>
        <div class="lawyer_conultation-wrapper">
          
            <div class="tabs_design-wrap three_tabs-layout">
                <div class="lawyer-tabs_lists">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link<?php echo e(@$title['active']=='upcoming' ? ' active':''); ?>" wire:click="upcomingConsultations()">Upcoming</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link<?php echo e(@$title['active']=='complete' ? ' active':''); ?>" wire:click="completeConsultations('complete')">Complete</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link<?php echo e(@$title['active']=='accepted' ? ' active':''); ?>" wire:click="acceptConsultations('accepted')">Accepted</a>
                        </li>
                    </ul>
                </div>

                <div class="lawyer-tabs_contents">

                    <div class="tab-content">

                  
                        <?php if(@$upcomingTab=='true'): ?>
                        <?php echo $__env->make('livewire.admin.consultation.upcoming', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>

                        <?php if(@$completeTab=='true'): ?>
                        <?php echo $__env->make('livewire.admin.consultation.complete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>

                        <?php if(@$acceptTab=='true'): ?>
                        <?php echo $__env->make('livewire.admin.consultation.accept', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>

                      
                    </div>
                </div>

            </div>
        </div>
    </div>
</div><?php /**PATH /home/texasbutchersmal/public_html/resources/views/livewire/admin/consultations.blade.php ENDPATH**/ ?>