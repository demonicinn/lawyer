<?php $__env->startSection('content'); ?>
<section class="body-banner min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('reschedule-booking',['bookingId' => $bookingId])->html();
} elseif ($_instance->childHasBeenRendered('ACtZD5A')) {
    $componentId = $_instance->getRenderedChildComponentId('ACtZD5A');
    $componentTag = $_instance->getRenderedChildComponentTagName('ACtZD5A');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ACtZD5A');
} else {
    $response = \Livewire\Livewire::mount('reschedule-booking',['bookingId' => $bookingId]);
    $html = $response->html();
    $_instance->logRenderedChild('ACtZD5A', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/pages/reschedule.blade.php ENDPATH**/ ?>