<?php echo e($slot); ?>

<?php /**PATH /home/texasbutchersmal/public_html/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>