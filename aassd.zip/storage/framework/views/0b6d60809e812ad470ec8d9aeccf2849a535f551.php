<?php $__env->startSection('content'); ?>
<section class="body-banner authentication-sec min-height-100vh login-sec">
	<div class="container">
		<div class="authentication-container">
			<div class="authentication-header">
				<h2>Forgot Password</h2>
			</div>
			<div class="lawyer-login">
				<?php echo Form::open(['route' => 'password.email', 'class'=>'user']); ?>

				<div class="white-shadow-box">

					<div class="form-grouph input-design<?php echo ($errors->has('email') ? ' has-error' : ''); ?>">
						<?php echo Form::label('email','Email', ['class' => 'form-label']); ?>

						<?php echo Form::email('email', request()->email ?? null, ['class' => ($errors->has('email') ? ' is-invalid' : '')]); ?>

					</div>

					<div class="form-grouph submit-design text-center pt-3">
						<button class="form-btn" type="submit"><?php echo e(__('Forgot Password')); ?></button>
					</div>

				</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>