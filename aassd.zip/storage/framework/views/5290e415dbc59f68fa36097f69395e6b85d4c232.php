<?php $__env->startSection('content'); ?>
<section class="body-banner dashboard_profile-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="go-back"><i class="fa-solid fa-arrow-left-long"></i> Back to Dashboard</a>
        </div>

        

        
        <div class="table-responsive table-design">
            <table style="width:100%">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Amount</th>
                        <th>Type</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="background: grey;">
                        <td><?php echo e(@$transaction->user->name); ?></td>
                        <td>$<?php echo e(@$transaction->amount); ?></td>
                        <td><?php echo e(@$transaction->payment_type ? ucfirst($transaction->payment_type) : ''); ?></td>
                        <td><?php echo e(@$transaction->created_at->format('Y-m-d')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div id="pagination-container" class="pagination-container-saved"><?php echo e($transactions->links()); ?></div>

      
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/admin/transactions/index.blade.php ENDPATH**/ ?>