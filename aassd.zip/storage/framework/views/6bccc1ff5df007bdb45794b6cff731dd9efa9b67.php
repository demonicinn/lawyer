<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('schedule-consultation', ['lawyerID' => $lawyerID])->html();
} elseif ($_instance->childHasBeenRendered('E602eem')) {
    $componentId = $_instance->getRenderedChildComponentId('E602eem');
    $componentTag = $_instance->getRenderedChildComponentTagName('E602eem');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('E602eem');
} else {
    $response = \Livewire\Livewire::mount('schedule-consultation', ['lawyerID' => $lawyerID]);
    $html = $response->html();
    $_instance->logRenderedChild('E602eem', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/schedule-consultation.blade.php ENDPATH**/ ?>