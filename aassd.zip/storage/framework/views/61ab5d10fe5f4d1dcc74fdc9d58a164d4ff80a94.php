<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/texasbutchersmal/public_html/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>