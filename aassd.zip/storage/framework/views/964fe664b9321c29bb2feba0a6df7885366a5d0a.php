<?php $__env->startSection('content'); ?>
<section class="body-banner narrow-down-inner-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-4">
            <h2>Select a practice area…</h2>
            <p>Check the box that best describes your needs.</p>
            <a href="<?php echo e(route('narrow.down')); ?>" class="go-back"><i class="fa-solid fa-arrow-left-long"></i> Go Back</a>
        </div>
        <div class="narrow-selection-box">
            <?php echo Form::open(['route' => 'lawyers', 'method'=>'get', 'class'=>'form-design']); ?>


                <div class="white-shadow-box">
                    
                    
                    
                    <?php
                        $count = count($litigations) / 2;
                        $count = number_format($count);
                    ?>
                    <div class="row">
                        <?php $__currentLoopData = $litigations->chunk($count); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $litigation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-grouph checkbox-design position-relative">
                                <input type="radio" name="litigations[]" value="<?php echo e($litigation->id); ?>">
                                <button class="checkbox-btn"></button>
                                <label><?php echo e($litigation->name); ?></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                
                <?php echo $errors->first('litigations', '<span class="help-block">:message</span>'); ?>



                <input type="hidden" name="latitude">
                <input type="hidden" name="longitude">
                <input type="hidden" name="type" value="litigation">
                
                <div class="form-confim-div">
                    <div class="form-grouph submit-design text-center">
                        <button class="btn-design-first" type="submit"><?php echo e(__ ('Confirm')); ?></button>
                    </div>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/litigations.blade.php ENDPATH**/ ?>