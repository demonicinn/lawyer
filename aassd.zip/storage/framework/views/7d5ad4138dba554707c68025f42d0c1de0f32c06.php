<?php $__env->startSection('content'); ?>
<section class="body-banner dashboard_profile-sec min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="go-back"><i class="fa-solid fa-arrow-left-long"></i> Back to Dashboard</a>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.state-bar')->html();
} elseif ($_instance->childHasBeenRendered('8c9BYRS')) {
    $componentId = $_instance->getRenderedChildComponentId('8c9BYRS');
    $componentTag = $_instance->getRenderedChildComponentTagName('8c9BYRS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8c9BYRS');
} else {
    $response = \Livewire\Livewire::mount('admin.state-bar');
    $html = $response->html();
    $_instance->logRenderedChild('8c9BYRS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/admin/state_bar/index.blade.php ENDPATH**/ ?>