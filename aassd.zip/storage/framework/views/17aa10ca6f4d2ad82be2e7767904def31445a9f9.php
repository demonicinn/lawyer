<?php $__env->startSection('content'); ?>
<section class="body-banner min-height-100vh">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="go-back"><i class="fa-solid fa-arrow-left-long"></i> Back to Dashboard</a>
        </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.categories')->html();
} elseif ($_instance->childHasBeenRendered('NV8jp4w')) {
    $componentId = $_instance->getRenderedChildComponentId('NV8jp4w');
    $componentTag = $_instance->getRenderedChildComponentTagName('NV8jp4w');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NV8jp4w');
} else {
    $response = \Livewire\Livewire::mount('admin.categories');
    $html = $response->html();
    $_instance->logRenderedChild('NV8jp4w', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<link href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/texasbutchersmal/public_html/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>