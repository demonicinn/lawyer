<div>
    <div class="add-search-box">
        <div class="add-litigations py-3">
            <button type="button" class="accept_btn showModal">Add</button>
        </div>
        <div class="form-group">
            <input wire:model="search" class="form-control search-box" type="text" placeholder="Search">
        </div>
    </div>

    <div class="table-responsive table-design">
        <table style="width:100%">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($state->name); ?></td>
                    <td>
                        <?php if($state->status=='1'): ?>
                        <button type="button" class="accept_btn">Active</button>
                        <?php else: ?>
                        <button type="button" class="decline-btn">De-active</button>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a class="edit-icons" href="javascript::void(0)" wire:click="edit('<?php echo e($state->id); ?>')"><i class="fas fa-pen"></i></a>
                        <a class="view-icon" href="javascript::void(0)" wire:click="delete('<?php echo e($state->id); ?>')"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div id="pagination-container" class="pagination-container-saved"><?php echo e($states->links()); ?></div>

    <!-- Accept Modal Start Here-->
    <div wire:ignore.self class="modal fade common_modal" id="stateForm" tabindex="-1" aria-labelledby="stateForm" aria-hidden="true">
        <div class="modal-dialog modal_style">
            <button type="button" class="btn btn-default close closeModal">
                <i class="fas fa-close"></i>
            </button>
            <div class="modal-content">
                <form>
                    <div class="modal-header modal_h">
                        <h3>Add/Edit Contract</h3>
                    </div>
                    <div class="modal-body">
                        <div>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" wire:model="name" class="form-control">
                                <?php echo $errors->first('name', '<span class="help-block">:message</span>'); ?>

                            </div>
                            <div class="form-group">
                                <label>Status</label></br>
                                <input type="radio" name="status" wire:model="status" value="1"> Active
                                <input type="radio" name="status" wire:model="status" value="0"> De-active
                                <?php echo $errors->first('status', '<span class="help-block">:message</span>'); ?>

                            </div>

                        </div>
                    </div>
                    <div class="text-center mb-3">
                        <button type="button" class="btn-design-first" wire:click="store" wire:loading.attr="disabled">
                            <i wire:loading wire:target="store" class="fas fa-spin fa-spinner"></i> Save
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <!-- Accept Modal Close Here-->
    <?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            window.livewire.on('stateFormClose', () => {
                $('#stateForm').modal('hide');
            });
            window.livewire.on('stateFormShow', () => {
                $('#stateForm').modal('show');
            });
        });
        $(document).on('click', '.showModal', function(e) {
            $('#stateForm').modal('show');
        });
        $(document).on('click', '.closeModal', function(e) {
            $('#stateForm').modal('hide');
        });
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/livewire/admin/state-bar.blade.php ENDPATH**/ ?>