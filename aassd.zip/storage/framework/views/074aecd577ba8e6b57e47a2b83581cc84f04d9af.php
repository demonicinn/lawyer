<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
	


<img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" class="logo" alt="<?php echo e($slot); ?>" style="width:100%; height:56px">

</a>
</td>
</tr>
<?php /**PATH /home/texasbutchersmal/public_html/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>