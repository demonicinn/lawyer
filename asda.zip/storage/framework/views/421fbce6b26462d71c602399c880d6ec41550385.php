<?php
$days = \App\Models\User::getDays();
$getTime = \App\Models\User::getTime();
?>

<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 working_hours">
    <div class="white-shadow-scnd-box" style="height:auto;">
        <div class="form-heading">
            <h4 class="h4-design">Working Hours</h4>
        </div>

        
        <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $hours = $user->lawyerHours()->where('day', $day)->get();
            ?>

            <div class="custom-control custom-switch input_add">
                <input type="checkbox" class="custom-control-input hoursDay" name="day[<?php echo e($day); ?>][selected]" <?php echo e(@$hours ? 'checked' : ''); ?>><span> <?php echo e($day); ?></span>
                <label class="custom-control-label"></label>

                <button style="display:<?php echo e(@$hours ? '' : 'none'); ?>" type="button" class="btn btn-primary clickHours <?php echo e($day); ?>" data-day="<?php echo e($day); ?>">+</button>
            </div>


            <div class="addNewHoursLayout <?php echo e($day); ?>" style="display:<?php echo e(@$hours ? '' : 'none'); ?>">
                
                <?php if($hours): ?>
                <?php $__currentLoopData = $hours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $j = $i+1;
                ?>
                <div class="form-flex layout layout-<?php echo e($j); ?>">

                    <?php echo Form::hidden('day['.$day.'][data]['.$j.'][id]', @$hour->id); ?>

                    <?php echo Form::hidden('day['.$day.'][data]['.$j.'][delete]', 'no', ['class'=>'delete']); ?>


                    <div class="form-grouph input-design<?php echo ($errors->has('from_time') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('from_time','From Time*', ['class' => 'form-label']); ?>    
                        <?php echo Form::select('day['.$day.'][data]['.$j.'][from_time]', @$getTime, @$hour->from_time ?? null, ['class' => ($errors->has('from_time') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('from_time', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph input-design<?php echo ($errors->has('to_time') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('to_time','To Time*', ['class' => 'form-label']); ?>    
                        <?php echo Form::select('day['.$day.'][data]['.$j.'][to_time]', @$getTime, @$hour->to_time ?? null, ['class' => ($errors->has('to_time') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('to_time', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <span class="btn_close deleteLayout" data-day="<?php echo e($day); ?>" data-id="<?php echo e($j); ?>">X</span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="form-flex layout layout-1">
                    <div class="form-grouph input-design<?php echo ($errors->has('from_time') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('from_time','From Time*', ['class' => 'form-label']); ?>    
                        <?php echo Form::select('day['.$day.'][data][1][from_time]', @$getTime, null, ['class' => ($errors->has('from_time') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('from_time', '<span class="help-block">:message</span>'); ?>

                    </div>
                    <div class="form-grouph input-design<?php echo ($errors->has('to_time') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('to_time','To Time*', ['class' => 'form-label']); ?>    
                        <?php echo Form::select('day['.$day.'][data][1][to_time]', @$getTime, null, ['class' => ($errors->has('to_time') ? ' is-invalid' : '')]); ?>

                        <?php echo $errors->first('to_time', '<span class="help-block">:message</span>'); ?>

                    </div>
                </div>

                <?php endif; ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>









        <div class="form-grouph select-design">
            <div class="form-grouph input-design">
                <h5 class="h5_titile_form pt-3">State bar admissions</h5>
            </div>
            <select id="mstate" name="state_category" class="select-block multiBoxes" multiple>
                <?php $__currentLoopData = $stateBar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($state->id); ?>" data-name="<?php echo e($state->name); ?>"
                        <?php $__currentLoopData = $lawyer_state_bar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($state->id==$item->state_bar_id): ?>
                        data-year="<?php echo e($item->year_admitted); ?>"
                        data-bar="<?php echo e($item->bar_number); ?>"
                        selected
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        >
                        <?php echo e($state->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php echo $errors->first('state_category', '<span class="help-block">:message</span>'); ?>

            <div class="stateHtml cat"></div>
        </div>




        <div class="form-grouph select-design">
            <div class="form-grouph input-design">
                <h5 class="h5_titile_form pt-3">Federal court admissions</h5>
            </div>
            <select id="mcategory" name="lawyer_category" class="select-block multiBoxes" multiple>
    
    
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($category->name); ?>">
                        <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($list->id); ?>" data-cat="<?php echo e($category->id); ?>" data-name="<?php echo e($list->name); ?>" 
                            <?php $__currentLoopData = $lawyer_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($list->id==$item->item_id): ?>
                            data-year="<?php echo e($item->year_admitted); ?>"
                            data-bar="<?php echo e($item->bar_number); ?>"
                            selected
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            >
                            <?php echo e($list->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php echo $errors->first('lawyer_category', '<span class="help-block">:message</span>'); ?>

            <div class="admissionHtml cat"></div>
        </div>
        
        
        <div class="form-grouph input-design<?php echo ($errors->has('year_experience') ? ' has-error' : ''); ?>">
            <label>Years of Experience <span class="label_color">?</span></label>
            <?php echo Form::text('year_experience', $details->year_experience ?? null, ['class' => ($errors->has('year_experience') ? ' is-invalid' : ''), 'maxlength'=>'2']); ?>

            <?php echo $errors->first('year_experience', '<span class="help-block">:message</span>'); ?>

        </div>

    </div>
</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/lawyer/profile/hours.blade.php ENDPATH**/ ?>