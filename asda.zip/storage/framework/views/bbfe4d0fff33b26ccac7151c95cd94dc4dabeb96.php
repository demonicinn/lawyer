<?php $__env->startSection('content'); ?>
<?php
    $authUser = auth()->user();
?>
<section class="lawyer_conultation-wrapper-sec">
    <div class="container">
        <div class="heading-paragraph-design text-center position-relative go-back-wrap mb-5">
            <h2><?php echo e(@$title['title']); ?></h2>
        </div>

        <div>
            <div class="lawyer_conultation-wrapper">
                <div class="tabs_design-wrap three_tabs-layout">

                    <?php echo $__env->make('pages.consultations.tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="lawyer-tabs_contents">
                        <div class="tab-content">
                            <div id="Upcoming" class="container tab-pane active">

                                <div class="table-responsive table-design">
                                    <table style="width:100%">
                                        <thead>
                                            <tr>
                                                <th><?php echo e($authUser->role=='user' ? 'Lawyer Name' : 'Name'); ?></th>
                                                <th>Practice Area</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $role = 'user';
                                            if($authUser->role == 'user'){
                                            $role = 'lawyer';
                                            }
                                            ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $upcomingConsultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcoming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                            <?php
                                            $start_time=date('g:i A', strtotime($upcoming->booking_time));
                                            $end_time=date('g:i A', strtotime($upcoming->booking_time. ' +30 minutes'));
                                            ?>
                                            <tr>
                                                <td><?php echo e($upcoming->$role->first_name); ?> <?php echo e($upcoming->$role->last_name); ?></td>
                                                <td>
                                                    <?php if($upcoming->search_data): ?>
                                                    <?php
                                                        $search = json_decode($upcoming->search_data);
                                                    ?>
                                                        <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($upcoming->search_type == 'litigations'): ?>
                                                            <?php echo e(litigationsData($id)); ?>

                                                            <?php else: ?>
                                                            <?php echo e(contractsData($id)); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(date('m-d-Y', strtotime($upcoming->booking_date))); ?></td>
                                                <td><?php echo e($start_time); ?> - <?php echo e($end_time); ?></td>
                                                <td>
                                                    <div class="dropdown reshedule_dropdowns">
                                                        <button class="toggle_cstm-btn" type="button">Reschedule</button>

                                                        <?php if($authUser->role == 'lawyer'): ?>

                                                        <div class="reshedule_wrap-box">
                                                            <span class="info_icns"><i class="fa-solid fa-circle-info"></i></span>
                                                            <p>Rescheduling consultation will hurt your ratings</p>
                                                            <div class="d-flex">
                                                                <a href="<?php echo e(route('reschedule.booking',$upcoming->id)); ?>" class="accept_btn showModal">Confirm</a>

                                                                <a class="cancel_dropdown-btn cancel_btn">Cancel</a>
                                                            </div>
                                                        </div>

                                                        <?php else: ?>

                                                        <div class="reshedule_wrap-box">
                                                            <span class="info_icns"><i class="fa-solid fa-circle-info"></i></span>
                                                            <p>Rescheduling consultation will hurt your ratings</p>
                                                            <div class="d-flex">
                                                                <a href="<?php echo e(route('reschedule.booking',$upcoming->id)); ?>" class="accept_btn showModal">Confirm</a>

                                                                <a class="cancel_dropdown-btn cancel_btn">Cancel</a>
                                                            </div>
                                                        </div>

                                                        <?php endif; ?>
                                                    </div>

                                                    <?php
                                                        $date1Days = \Carbon\Carbon::parse($upcoming->booking_date.' '.$upcoming->booking_time)->subtract(1, 'days')->format('Y-m-d h:i:s');

                                                        $cDate = date('Y-m-d h:i:s');
                                                    ?>
                                                    <?php if($authUser->role == 'user' && $cDate <= $date1Days): ?>
                                                    <button class="toggle_cstm-btn" style="background-color:#f93f64;" type="button" onclick="cancelBooking(`<?php echo e($upcoming->id); ?>`)">Cancel Booking</button>

                                                    <form id="cancel-form-<?php echo e($upcoming->id); ?>" action="<?php echo e(route('consultations.upcoming.cancel', $upcoming->id)); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                    </form>
                                                     <?php endif; ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tfoot>
                                            <tr>
                                                <td colspan="6" class="text-center pt-3">
                                                    <h4>No consultations found</h4>
                                                </td>
                                            </tr>
                                        </tfoot>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function cancelBooking(id) {

        Swal.fire({
            title: "Are you sure?",
            text: "Cancel Booking",
            type: "danger",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, Cancel!",
            closeOnConfirm: false

        }).then((result) => {

            if (result.isConfirmed) {
                $("#cancel-form-"+id).submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/pages/consultations/upcoming.blade.php ENDPATH**/ ?>