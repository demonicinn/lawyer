<?php
    $message = 'Monthly/Yearly Payment Plans';
?>
<div>
    <div class="billing_account-wrapper form-design biling_btn_wrapr">
        <form>


            <?php if(@$currentPlan): ?>
            <?php
                $message = 'Upgrade Payment Plans';
            ?>
            <div class="alert alert-warning">
                <p>Current Subscription Plan <strong><?php echo e($currentPlan->subscription->name); ?></strong></p>
                <p>Expires on: <strong><?php echo e($currentPlan->to_date); ?></strong></p>

                <?php if(@$user->auto_renew=='1'): ?>
                <button type="button" class="btn-design-first" wire:click="removeSubscription">Cancel Subscription</button>
                <?php else: ?>
                <button type="button" class="btn-design-first">Subscription Canceled</button>
                <?php endif; ?>
            </div>
            <?php endif; ?>


            <div class="row">

                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="white-shadow-scnd-box">
                        <div class="form-heading mb-4">
                            <h4 class="h4-design"><?php echo e(@$message); ?></h4>
                        </div>
                        <div class="payment_plans">

                            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="payment_plans-inner position-relative">
                                <input type="radio" value="<?php echo e($subscription->id); ?>" name="subscription" wire:click="setSubscription('<?php echo e($subscription->id); ?>', '<?php echo e($subscription->type); ?>')">
                                <div class="payemnt_selection-box">
                                    <h4><?php echo e($subscription->name); ?></h4>
                                    <?php if(@$subscription->price): ?>
                                    <h5>$<?php echo e($subscription->price); ?><?php echo e($subscription->types); ?></h5>
                                    <?php endif; ?>
                                </div>
                                <span class="payment_confirmation-form"><i class="fa-solid fa-check"></i></span>
                                
                                <?php if(@$subscription->type=='yearly' && $subscriptionMonthly > 0): ?>
                                <span class="price_saving-tag">$<?php echo e($subscriptionMonthly - $subscription->price); ?> Savings</span>
                                <?php endif; ?>


                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php echo $errors->first('subscription', '<span class="help-block">:message</span>'); ?>


                            <?php if(!$currentPlan): ?>
                            <p>You will be on <?php echo e(env('FREE_SUBSCRIPTION')); ?> days trial after that you will get charged based on your plan selection if you have not canceled your plan</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <?php if($type != 'free'): ?>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="white-shadow-scnd-box">
                        <div class="form-heading">
                            <h4 class="h4-design">Billing Information</h4>
                        </div>
                        <div class="billing-info_form-inputs">
                            <div class="form-grouph input-design">
                                <label>Name on Card</label>
                                <input type="text" placeholder="Name on Card" wire:model="card_name">
					            <?php echo $errors->first('card_name', '<span class="help-block">:message</span>'); ?>

                            </div>
                            <div class="form-grouph input-design">
                                <label>Card Number</label>
                                <input type="number" maxlength="16" placeholder="Credit Card Number" wire:model="card_number">
					            <?php echo $errors->first('card_number', '<span class="help-block">:message</span>'); ?>

                            </div>
                            <div class="form-flex">
                                <div class="form-grouph select-design">
                                    <label>Expiration Month</label>
                                    <select wire:model="expire_month">
                                        <option value="">Select Month</option>
                                        <?php for($i = 1; $i <=12; $i++): ?>
                                        <option value="<?php echo e($i<=9 ? '0'.$i : $i); ?>"><?php echo e(date('F', mktime(0,0,0,$i))); ?></option>
                                        <?php endfor; ?>
                                    </select>
					                <?php echo $errors->first('expire_month', '<span class="help-block">:message</span>'); ?>

                                </div>
                                <div class="form-grouph select-design">
                                    <label>Expiration Year</label>
                                    <select wire:model="expire_year">
                                        <option value="">Select Year</option>
                                        <?php for($i = 0; $i <10; $i++): ?>
                                        <?php $year = date('Y') + $i; ?>
                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <?php echo $errors->first('expire_year', '<span class="help-block">:message</span>'); ?>

                                </div>
                                <div class="form-grouph input-design">
                                    <label>CVV </label>
                                    <input type="number" maxlength="4" placeholder="CVV" wire:model="cvv">
					                <?php echo $errors->first('cvv', '<span class="help-block">:message</span>'); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-center mt-5">
                    <div class="form-grouph submit-design text-center">
                        <button type="button" class="btn-design-first" wire:click="store" wire:loading.attr="disabled">
                            <i wire:loading wire:target="store" class="fa fa-spin fa-spinner"></i> Confirm
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div><?php /**PATH /home/gurpreet/Desktop/git/2022/dj/august/lawyer/resources/views/livewire/lawyer/subscriptions.blade.php ENDPATH**/ ?>